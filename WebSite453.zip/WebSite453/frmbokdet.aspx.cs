using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            String s = Request.QueryString["bokid"].ToString();
            SqlDataAdapter adp = new SqlDataAdapter("select bokcod,bokisb,titnam,pubnam,bokprc,bokpic,bokcmt,boknop,cltnam  from tbbok,tbtit,tbpub,tbclt where boktitcod=titcod and bokpubcod=pubcod and bokcltcod=cltcod and bokcod=" + s, ConfigurationManager.ConnectionStrings["cn"].ConnectionString);
            DataSet ds = new DataSet();
            adp.Fill(ds);
            DataList1.DataSource = ds;
            DataList1.DataBind();
        }
    }
    protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Response.Redirect("frmviewcart.aspx?bokid=" + DataList1.DataKeys[DataList1.SelectedIndex].ToString());
    }
}
