using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Default2 : System.Web.UI.Page
{
    nsb2b.clscatprp objprp = new nsb2b.clscatprp();
    nsb2b.clscat obj = new nsb2b.clscat();
    protected void Page_Load(object sender, EventArgs e)
    {
        Label lb = (Label)(Master.FindControl("label1"));
        lb.Text = "Category";

    }
    protected void btnsav_Click(object sender, EventArgs e)
    {
        objprp.catnam = txtcatnam.Text;
        obj.save_rec(objprp);
        lstcatnam.DataBind();
        txtcatnam.Text = "";
        txtcatnam.Focus();
    }
    protected void btnupd_Click(object sender, EventArgs e)
    {
        objprp.catcod = Convert.ToInt32(lstcatnam.SelectedValue);
        objprp.catnam = txtcatnam.Text;
        obj.update_rec(objprp);
        lstcatnam.DataBind();
        txtcatnam.Text = "";
        txtcatnam.Focus();
    }
    protected void btndel_Click(object sender, EventArgs e)
    {
        objprp.catcod = Convert.ToInt32(lstcatnam.SelectedValue);
        
        obj.delete_rec(objprp);
        lstcatnam.DataBind();
        txtcatnam.Text = "";
        txtcatnam.Focus();
    }
    protected void btncan_Click(object sender, EventArgs e)
    {
        txtcatnam.Text = "";
        txtcatnam.Focus();
    }
    protected void lstcatnam_SelectedIndexChanged(object sender, EventArgs e)
    {
        txtcatnam.Text = lstcatnam.SelectedItem.Text;
    }
}
