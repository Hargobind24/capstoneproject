using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Collections.Generic;


public partial class client_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Button3.Attributes.Add("OnClick", "xyz('aspnetForm.ctl00_ContentPlaceHolder1_TextBox1');");
        Button4.Attributes.Add("OnClick", "xyz('aspnetForm.ctl00_ContentPlaceHolder1_TextBox2');");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        if (DropDownList1.SelectedValue == "ALL")
        {
            bind();
        }
        else if (DropDownList1.SelectedValue == "PENDING")
        {
            bindsome();
        }
        else if (DropDownList1.SelectedValue == "DELIVERED")
        {
            bindsome1();
        }

        Button2.Visible = true;

  //  //    string st;
      // st = "select ordcod,orddat,ordsts,regnam,orddelnam,orddelphn,orddelmob,orddeladd from tbord,tbreg where ordregcod=regcod and orddat >='" + TextBox1.Text + "' and orddat <='" + TextBox2.Text + "' and ordsts='P'";

  //      SqlDataAdapter adp = new SqlDataAdapter(st, ConfigurationManager.ConnectionStrings["cn"].ConnectionString);
  //      DataSet ds = new DataSet();
  //      adp.Fill(ds);
  //      GridView1.DataSource = ds;
  //      GridView1.DataBind();
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        string st;
        st = "select titnam,pubnam,cltnam,orddetqty,bokprc from tborddet,tbbok,tbtit,tbclt,tbpub where orddetbokmodcod=bokcod and boktitcod=titcod and bokcltcod=cltcod and bokpubcod=pubcod and orddetordcod=" + GridView1.DataKeys[GridView1.SelectedIndex][0].ToString();

        SqlDataAdapter adp = new SqlDataAdapter(st, ConfigurationManager.ConnectionStrings["cn"].ConnectionString);
        DataSet ds = new DataSet();
        adp.Fill(ds);
        GridView2.DataSource = ds;
        GridView2.DataBind();
        
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        for (Int32 i = 0; i < GridView1.Rows.Count; i++)
        {
            CheckBox c = (CheckBox)(GridView1.Rows[i].FindControl("ck1"));
            if (c.Checked == true)
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = "database=gagan18;uid=sa;pwd=sumeet";
                con.Open();
                SqlCommand cmd = new SqlCommand("update tbord set ordsts='D' where ordcod=" + GridView1.DataKeys[i][0].ToString(), con);
                cmd.ExecuteNonQuery();
            }
        }
    }


    private void bind()
    {
          string st;
        st = "select ordcod,orddat,ordsts,regnam,orddelnam,orddelphn,orddelmob,orddeladd from tbord,tbreg where ordregcod=regcod and orddat >='" + TextBox1.Text + "' and orddat <='" + TextBox2.Text + "'";

        SqlDataAdapter adp = new SqlDataAdapter(st, ConfigurationManager.ConnectionStrings["cn"].ConnectionString);
        DataSet ds = new DataSet();
        adp.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }

    private void bindsome()
    {


        string st;
        st = "select ordcod,orddat,ordsts,regnam,orddelnam,orddelphn,orddelmob,orddeladd from tbord,tbreg where ordregcod=regcod and orddat >='" + TextBox1.Text + "' and orddat <='" + TextBox2.Text + "' and  ordsts='P'" ;

        SqlDataAdapter adp = new SqlDataAdapter(st, ConfigurationManager.ConnectionStrings["cn"].ConnectionString);
        DataSet ds = new DataSet();
        adp.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }
    private void bindsome1()
    {

        string st;
        st = "select ordcod,orddat,ordsts,regnam,orddelnam,orddelphn,orddelmob,orddeladd from tbord,tbreg where ordregcod=regcod and orddat >='" + TextBox1.Text + "' and orddat <='" + TextBox2.Text + "' and  ordsts='D'";

        SqlDataAdapter adp = new SqlDataAdapter(st, ConfigurationManager.ConnectionStrings["cn"].ConnectionString);
        DataSet ds = new DataSet();
        adp.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }



    protected void GridView1_DataBound(object sender, EventArgs e)
    {
        for (Int32 i = 0; i < GridView1.Rows.Count; i++)
        {
            if (GridView1.DataKeys[i][1].ToString() == "D")
            {
                CheckBox ck = (CheckBox)(GridView1.Rows[i].FindControl("ck1"));
                ck.Enabled = false;
            }
        }
    }
}
