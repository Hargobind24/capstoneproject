using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Default2 : System.Web.UI.Page
{
    nsb2b.clsctyprp objprp = new nsb2b.clsctyprp();
    nsb2b.clscty obj = new nsb2b.clscty();
    protected void Page_Load(object sender, EventArgs e)
    {
        Label lb = (Label)(Master.FindControl("label1"));
        lb.Text = "City";
    }
    protected void btnsav_Click(object sender, EventArgs e)
    {

        objprp.ctynam = txtctynam.Text;
        objprp.ctystacod = Convert.ToInt32(drpstanam.SelectedValue);
        obj.save_rec(objprp);

        lstctynam.DataBind();
        txtctynam.Text = "";
        txtctynam.Focus();

    }
    
    protected void btnupd_Click(object sender, EventArgs e)
    {
        objprp.ctycod = Convert.ToInt32(lstctynam.SelectedValue);
        objprp.ctynam = txtctynam.Text;
        objprp.ctystacod = Convert.ToInt32(drpstanam.SelectedValue);
        obj.update_rec(objprp);

        lstctynam.DataBind();
        txtctynam.Text = "";
        txtctynam.Focus();
    }
    protected void btndel_Click(object sender, EventArgs e)
    {
        objprp.ctycod = Convert.ToInt32(lstctynam.SelectedValue);
        obj.delete_rec(objprp);

        lstctynam.DataBind();
        txtctynam.Text = "";
        txtctynam.Focus();
    }
    protected void btncan_Click(object sender, EventArgs e)
    {
        txtctynam.Text = "";
        txtctynam.Focus();
    }

    protected void lstctynam_SelectedIndexChanged(object sender, EventArgs e)
    {
        txtctynam.Text = lstctynam.SelectedItem.Text;

    }



    protected void drpcntnam_SelectedIndexChanged(object sender, EventArgs e)
    {
        drpstanam.DataBind();
        
    }
}
