using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Default2 : System.Web.UI.Page
{
    nsb2b.clsautprp objprp = new nsb2b.clsautprp();
    nsb2b.clsaut obj = new nsb2b.clsaut();
   protected void Page_Load(object sender, EventArgs e)
    {


        Label lb = (Label)(Master.FindControl("label1"));
        lb.Text = "Author";
    }
    protected void btnsav_Click(object sender, EventArgs e)
    {
        objprp.autnam = txtautnam.Text;
        obj.save_rec(objprp);
        lstautnam.DataBind();
        txtautnam.Text = "";
        txtautnam.Focus();
    }
    protected void btnupd_Click(object sender, EventArgs e)
    {
        objprp.autcod = Convert.ToInt32(lstautnam.SelectedValue);
        objprp.autnam = txtautnam.Text;
        obj.update_rec(objprp);
        lstautnam.DataBind();
        txtautnam.Text = "";
        txtautnam.Focus();
    }
    protected void btndel_Click(object sender, EventArgs e)
    {
        objprp.autcod = Convert.ToInt32(lstautnam.SelectedValue);
        obj.delete_rec(objprp);
        lstautnam.DataBind();
        txtautnam.Text = "";
        txtautnam.Focus();
    }
    protected void btncan_Click(object sender, EventArgs e)
    {
        txtautnam.Text = "";
        txtautnam.Focus();
    }
    protected void lstautnam_SelectedIndexChanged(object sender, EventArgs e)
    {
        txtautnam.Text = lstautnam.SelectedItem.Text;
    }
}
