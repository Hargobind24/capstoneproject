using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Default2 : System.Web.UI.Page
{
    nsb2b.clscntprp objprp = new nsb2b.clscntprp();
    nsb2b.clscnt obj = new nsb2b.clscnt();
    protected void Page_Load(object sender, EventArgs e)
    {
        Label lb = (Label)(Master.FindControl("label1"));
        lb.Text = "country";
        this.SmartNavigation = true;

    }
    protected void btnsav_Click(object sender, EventArgs e)
    {
        
    }
    protected void btnupd_Click(object sender, EventArgs e)
    {
        objprp.cntcod = Convert.ToInt32(lstcntnam.SelectedValue);
        objprp.cntnam = txtcntnam.Text;
        obj.update_rec(objprp);
        lstcntnam.DataBind();
        txtcntnam.Text = "";
        txtcntnam.Focus();

    }
    protected void btndel_Click(object sender, EventArgs e)
    {
        objprp.cntcod = Convert.ToInt32(lstcntnam.SelectedValue);
        obj.delete_rec(objprp);
        lstcntnam.DataBind();
        txtcntnam.Text = "";
        txtcntnam.Focus();
    }
    protected void btncan_Click(object sender, EventArgs e)
    {
        txtcntnam.Text = "";
        txtcntnam.Focus();
    }
    protected void lstcntnam_SelectedIndexChanged(object sender, EventArgs e)
    {
        txtcntnam.Text = lstcntnam.SelectedItem.Text;
    }    protected void btnsav_Click1(object sender, EventArgs e)
    {
        objprp.cntnam = txtcntnam.Text;
        obj.save_rec(objprp);
        lstcntnam.DataBind();
        txtcntnam.Text = "";
        txtcntnam.Focus();
    }
}
