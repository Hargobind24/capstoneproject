using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Default2 : System.Web.UI.Page
{
    nsb2b.clstitprp objprp = new nsb2b.clstitprp();
    nsb2b.clstit obj = new nsb2b.clstit();

    protected void Page_Load(object sender, EventArgs e)
    {
        Label lb = (Label)(Master.FindControl("label1"));
        lb.Text = "Title";
    }
    protected void btnsav_Click(object sender, EventArgs e)
    {
        objprp.titnam = txttitnam.Text;
        objprp.titsubcod = Convert.ToInt32(drpsubnam.SelectedValue);
        obj.save_rec(objprp);
        lsttitnam.DataBind();
        txttitnam.Text = "";
        txttitnam.Focus();

    }
    protected void btnupd_Click(object sender, EventArgs e)
    {
        objprp.titcod = Convert.ToInt32(lsttitnam.SelectedValue);
        objprp.titnam = txttitnam.Text;
        objprp.titsubcod = Convert.ToInt32(drpsubnam.SelectedValue);
        obj.update_rec(objprp);

        lsttitnam.DataBind();
        txttitnam.Text = "";
        txttitnam.Focus();
    }
    protected void btndel_Click(object sender, EventArgs e)
    {
        objprp.titcod = Convert.ToInt32(lsttitnam.SelectedValue);
        obj.delete_rec(objprp);
        lsttitnam.DataBind();
        txttitnam.Text = "";
        txttitnam.Focus();
    }
    protected void btncan_Click(object sender, EventArgs e)
    {
         txttitnam.Text = "";
         txttitnam.Focus();
    }
    protected void lsttitnam_SelectedIndexChanged(object sender, EventArgs e)
    {
        txttitnam.Text = lsttitnam.SelectedItem.Text;


    }


    protected void drpcatnam_SelectedIndexChanged(object sender, EventArgs e)
    {
        drpsubnam.DataBind();
    }
}
