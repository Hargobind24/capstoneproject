using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Default2 : System.Web.UI.Page
{
    nsb2b.clspubprp objprp = new nsb2b.clspubprp();
    nsb2b.clspub obj = new nsb2b.clspub();
    protected void Page_Load(object sender, EventArgs e)
    {

        Label lb = (Label)(Master.FindControl("label1"));
        lb.Text = "Publisher";
    }
    protected void btnsav_Click(object sender, EventArgs e)
    {
        objprp.pubnam = txtpubnam.Text;
        obj.save_rec(objprp);
        lstpubnam.DataBind();
        txtpubnam.Text = "";
        txtpubnam.Focus();
    }
    protected void btnupd_Click(object sender, EventArgs e)
    {
        objprp.pubcod = Convert.ToInt32(lstpubnam.SelectedValue);
        objprp.pubnam = txtpubnam.Text;
        obj.update_rec(objprp);
        lstpubnam.DataBind();
        txtpubnam.Text = "";
        txtpubnam.Focus();
    }
    protected void btndel_Click(object sender, EventArgs e)
    {
        objprp.pubcod = Convert.ToInt32(lstpubnam.SelectedValue);
        obj.delete_rec(objprp);
        lstpubnam.DataBind();
        txtpubnam.Text = "";
        txtpubnam.Focus();
    }
    protected void btncan_Click(object sender, EventArgs e)
    {
        txtpubnam.Text = "";
        txtpubnam.Focus();
    }
    protected void lstpubnam_SelectedIndexChanged(object sender, EventArgs e)
    {
        txtpubnam.Text = lstpubnam.SelectedItem.Text;    
       
    }

}
