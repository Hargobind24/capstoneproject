using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Default2 : System.Web.UI.Page
{
    nsb2b.clsstaprp objprp = new nsb2b.clsstaprp();
    nsb2b.clssta obj = new nsb2b.clssta();
    protected void Page_Load(object sender, EventArgs e)
    {
        Label lb=(Label)(Master.FindControl("label1"));
        lb.Text = "State";
    }
    protected void btnsav_Click(object sender, EventArgs e)
    {
        objprp.stanam = txtstanam.Text;
        objprp.stacntcod = Convert.ToInt32(drpcntnam.SelectedValue);
        obj.save_rec(objprp);
        
        lststanam.DataBind();
        txtstanam.Text = "";
        txtstanam.Focus();
    }
    protected void btnupd_Click(object sender, EventArgs e)
    {
        objprp.stacod = Convert.ToInt32(lststanam.SelectedValue);
        objprp.stanam = txtstanam.Text;
        objprp.stacntcod = Convert.ToInt32(drpcntnam.SelectedValue);
        obj.update_rec(objprp);
        
        lststanam.DataBind();
        txtstanam.Text = "";
        txtstanam.Focus();
    }
    protected void btndel_Click(object sender, EventArgs e)
    {

        objprp.stacod = Convert.ToInt32(lststanam.SelectedValue);
        obj.delete_rec(objprp);
        lststanam.DataBind();
        txtstanam.Text = "";
        txtstanam.Focus();
    }
    protected void btncan_Click(object sender, EventArgs e)
    {
        txtstanam.Text = "";
        txtstanam.Focus();
    }
    protected void lststanam_SelectedIndexChanged(object sender, EventArgs e)
    {
        txtstanam.Text = lststanam.SelectedItem.Text;
    }
}
