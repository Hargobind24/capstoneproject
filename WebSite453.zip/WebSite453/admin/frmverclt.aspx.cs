using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Default2 : System.Web.UI.Page
{
    nsb2b.clsclt obj = new nsb2b.clsclt();
    nsb2b.clscltprp objprp = new nsb2b.clscltprp();
    nsb2b.clsusr obj1 = new nsb2b.clsusr();
    nsb2b.clsusrprp objprp1 = new nsb2b.clsusrprp();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList2.SelectedIndex == 1)
        {
            Panel1.Visible = true;
            Panel2.Visible = false;
        }
        else if (DropDownList2.SelectedIndex == 2)
        {
            Panel2.Visible = true;
            Panel1.Visible = false;
        }
        else
        {
            Panel1.Visible = false;
            Panel2.Visible = false;
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //Random r = new Random();
        //objprp1.usrpwd = r.Next(30000);
        //Guid.NewGuid().ToString();
        if (DropDownList2.SelectedIndex == 1)
        {
            objprp.cltcod = Convert.ToInt32(DropDownList1.SelectedValue);
            objprp.cltsts = "y";
            obj.updatests_rec(objprp);
            objprp1.usrnam =TextBox1.Text;
            objprp1 .usrpwd =TextBox2.Text;
            objprp1.usrsts ="C";
            objprp1.usrcltregcod =Convert.ToInt32(DropDownList1.SelectedValue );
            obj1.save_rec(objprp1);
        }
        else if (DropDownList2.SelectedIndex == 2)
        {
             objprp.cltcod = Convert.ToInt32(DropDownList1.SelectedValue);
             objprp.cltsts = "r";
            obj.updatests_rec(objprp);
        }
    }
    
}
