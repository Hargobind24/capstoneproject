using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
      if (Session["ss"] == null)
        {
            DataTable tb = new DataTable("Table");
            tb.Columns.Add(new DataColumn("Book Code", Type.GetType("System.Int32")));
            tb.Columns.Add(new DataColumn("ISBN",Type.GetType("System.String")));
            tb.Columns.Add(new DataColumn("Title", Type.GetType("System.String")));
            tb.Columns.Add(new DataColumn("Quantity", Type.GetType("System.Int32")));
            tb.Columns.Add(new DataColumn("Price", Type.GetType("System.Int32")));
            tb.Columns.Add(new DataColumn("Discount", Type.GetType("System.Int32")));
            tb.Columns.Add(new DataColumn("Amount", Type.GetType("System.Int32")));
            tb.Columns["Amount"].Expression = "Price*Quantity-Discount*Quantity";
            Session["ss"] = tb;
        }
        if (Page.IsPostBack == false)
        {
            DataTable tbl = (DataTable)(Session["ss"]);
            Int32 i = Convert.ToInt32(Request.QueryString["bokid"]);
            String s = "select bokcod,bokisb,titnam,bokprc from tbbok,tbtit where boktitcod=titcod and bokcod=" + i.ToString() + ";select disamt from tbdis where disbokmodcod=" + i.ToString();
            SqlDataAdapter adp = new SqlDataAdapter(s, ConfigurationManager.ConnectionStrings["cn"].ConnectionString);
            DataSet ds = new DataSet();
            adp.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                DataRow r = tbl.NewRow();
                r[0] = Convert.ToInt32(ds.Tables[0].Rows[0][0]);
                r[1] = ds.Tables[0].Rows[0][1].ToString();
                r[2] = ds.Tables[0].Rows[0][2].ToString();
                r[3] = 1;
                r[4] = Convert.ToInt32(ds.Tables[0].Rows[0][3]);
                if (ds.Tables[1].Rows.Count > 0)
                {
                    r[5] = Convert.ToInt32(ds.Tables[1].Rows[0][0]);
                }
                else
                {
                    r[5] = 0;
                }
                tbl.Rows.Add(r);
            }
            GridView1.DataSource = tbl;
            GridView1.DataBind();
            Label1.Text = tbl.Compute("sum(Amount)", "").ToString();
            Session["amount"] = Convert.ToInt32(Label1.Text);
        }
    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        DataTable tb = (DataTable)(Session["ss"]);
        GridView1.EditIndex = e.NewEditIndex;
        GridView1.DataSource = tb;
        GridView1.DataBind();
    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        DataTable tb = (DataTable)(Session["ss"]);
        GridView1.EditIndex = -1;
        GridView1.DataSource = tb;
        GridView1.DataBind();
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        DataTable tb = (DataTable)(Session["ss"]);
        tb.Rows.RemoveAt(e.RowIndex);
        Label1.Text = tb.Compute("sum(Amount)", "").ToString();
        Session["amount"] = Convert.ToInt32(Label1.Text);
        GridView1.DataSource = tb;
        GridView1.DataBind();
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        DataTable tb = (DataTable)(Session["ss"]);
        tb.Rows[e.RowIndex][3] = Convert.ToInt32(((TextBox)(GridView1.Rows[e.RowIndex].Cells[4].FindControl("t1"))).Text);
        Label1.Text = tb.Compute("sum(Amount)", "").ToString();
        Session["amount"] = Convert.ToInt32(Label1.Text);
     //   GridView1.EditIndex = -1;
        GridView1.DataSource = tb;
        GridView1.DataBind();
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("frmhom.aspx");
    }
    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("frmchkusr.aspx");
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
