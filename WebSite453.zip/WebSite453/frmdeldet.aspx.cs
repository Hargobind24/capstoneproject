using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class frmdeldet : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Panel1.Visible = false;
        Panel2.Visible = true;
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        nsb2b.clsord obj = new nsb2b.clsord();
        nsb2b.clsordprp objprp = new nsb2b.clsordprp();
        nsb2b.clsorddet obj1 = new nsb2b.clsorddet();
        nsb2b.clsorddetprp objprp1 = new nsb2b.clsorddetprp();
        Int32 a = obj.getauto();
        objprp.ordcod = a;
        objprp.orddat = DateTime.Now;
        objprp.orddelnam = TextBox1.Text;
        objprp.orddeladd = TextBox2.Text;
        objprp.ordctycod = Convert.ToInt32(DropDownList3.SelectedValue);
        objprp.orddelphn = TextBox3.Text;
        objprp.orddelmob = TextBox4.Text;
        objprp.ordregcod = Convert.ToInt32(Session["cltcod"]);
        objprp.ordsts = 'P';
        objprp.ordamt = Convert.ToInt32(Session["amount"]);
        obj.save_rec(objprp);
        DataTable tb = (DataTable)(Session["ss"]);
        for (Int32 i = 0; i < tb.Rows.Count; i++)
        {
            objprp1.orddetordcod = a;
            objprp1.orddetbokmodcod = Convert.ToInt32(tb.Rows[i]["Book Code"]);
            objprp1.orddetqty = Convert.ToInt32(tb.Rows[i]["Quantity"]);
            obj1.save_rec(objprp1);
        }
        Panel1.Visible = false;
        Panel2.Visible = false;
        Label1.Visible = true;
        Label1.Text = "Congrats! Your order has been placed and order no is " + a.ToString();
    }
}
