using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            SqlDataAdapter adp = new SqlDataAdapter("select count(*) from tbdis", ConfigurationManager.ConnectionStrings["cn"].ConnectionString);
            DataSet ds = new DataSet();
            adp.Fill(ds);
            Int32 nor = Convert.ToInt32(ds.Tables[0].Rows[0][0]);
            Int32 c;
            if (nor % 8 == 0)
            {
                c = nor / 8;
            }
            else
            {
                c = nor / 8 + 1;
            }
            ArrayList a = new ArrayList();
            for (Int32 i = 1; i <= c; i++)
            {
                a.Add(i.ToString());
            }
            DataList2.DataSource = a;
            DataList2.DataBind();
            bind(1);
        }
    }
    private void bind(Int32 pgno)
    {
        SqlDataAdapter adp = new SqlDataAdapter("pagedisbok", ConfigurationManager.ConnectionStrings["cn"].ConnectionString);
        adp.SelectCommand.CommandType = CommandType.StoredProcedure;
        adp.SelectCommand.Parameters.Add("@pageno", SqlDbType.Int).Value = pgno;
        DataSet ds = new DataSet();
        adp.Fill(ds);
        DataList1.DataSource = ds;
        DataList1.DataBind();

    }
    protected void DataList2_EditCommand(object source, DataListCommandEventArgs e)
    {
        bind(Convert.ToInt32(e.Item.ItemIndex) + 1);
    }
    protected void DataList1_EditCommand(object source, DataListCommandEventArgs e)
    {
        String s = DataList1.DataKeys[e.Item.ItemIndex].ToString();
        Response.Redirect("frmbokdet.aspx?bokid=" + s);
    }
    protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Response.Redirect("frmviewcart.aspx?bokid=" + DataList1.DataKeys[DataList1.SelectedIndex].ToString());
    }
}
