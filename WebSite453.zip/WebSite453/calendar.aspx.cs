using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class calendar : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {

    }
    protected void Calendar1_DayRender(object sender, DayRenderEventArgs e)
    {
        e.Cell.Controls.Clear();
        HtmlGenericControl lk = new HtmlGenericControl();
        lk.TagName = "a";
        lk.InnerText = e.Day.DayNumberText;
        lk.Attributes["href"] = String.Format("javascript:window.opener.document.{0}.value='{1}';window.close()", Request.QueryString["aa"].ToString(), e.Day.Date.ToShortDateString());
        e.Cell.Controls.Add(lk);
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        DateTime d = new DateTime(Convert.ToInt32(DropDownList1.SelectedValue), Convert.ToInt32(DropDownList2.SelectedValue), 1);
        Calendar1.VisibleDate = d;
    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        DateTime d = new DateTime(Convert.ToInt32(DropDownList1.SelectedValue), Convert.ToInt32(DropDownList2.SelectedValue), 1);
        Calendar1.VisibleDate = d;
    }
}
