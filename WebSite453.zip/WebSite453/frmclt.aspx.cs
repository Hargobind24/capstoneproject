using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Default2 : System.Web.UI.Page
{
    nsb2b.clscltprp objprp = new nsb2b.clscltprp();
    nsb2b.clsclt obj = new nsb2b.clsclt();
    protected void Page_Load(object sender, EventArgs e)
    {
       
      
        this.SmartNavigation = true;
    }
    protected void btnsav_Click(object sender, EventArgs e)
    {
        objprp.cltnam = txtcltnam.Text;
        objprp.cltadd = txtcltadd.Text;
        objprp.cltctycod = Convert.ToInt32(drpctynam.SelectedValue);
        objprp.cltphn = txtcltphn.Text;
        objprp.cltpin = txtcltpin.Text;
        objprp.cltfax = txtcltfax.Text;
        objprp.clteml = txtclteml.Text;
        objprp.clturl = txtclturl.Text;
        objprp.cltprf = txtcltprf.Text;
        objprp.cltconnam = txtcltconnam.Text;        
        objprp.cltconphn = txtcltconphn.Text;
        objprp.cltsts = "N";
        objprp.cltrgn = "";
        objprp.cltconmob = txtcltconmob.Text;
        String st = FileUpload1.PostedFile.FileName;
        Int32 i = st.LastIndexOf('\\');
        String fn = st.Substring(i + 1);
        objprp.cltpic = fn;
        obj.save_rec(objprp);
        //txtcltnam.Text = "";
        //txtcltadd.Text = "";     
        //txtcltphn.Text = "";
        //txtcltpin.Text = "";
        //txtcltfax.Text = "";
        //txtclteml.Text = "";
        //txtclturl.Text = "";
        //txtcltprf.Text = "";
        //txtcltconnam.Text = "";
        //txtcltconmob.Text = "";
        //txtcltconphn.Text = "";
        //txtcltnam.Focus();

        }
    protected void btncan_Click(object sender, EventArgs e)
    {
        txtcltnam.Text = "";
        txtcltadd.Text = "";
        txtcltphn.Text = "";
        txtcltpin.Text = "";
        txtcltfax.Text = "";
        txtclteml.Text = "";
        txtclturl.Text = "";
        txtcltprf.Text = "";
        txtcltconnam.Text = "";
        txtcltconmob.Text = "";
        txtcltconphn.Text = "";

    }
    protected void txtcltnam_TextChanged(object sender, EventArgs e)
    {

    }
    protected void drpcntnam_SelectedIndexChanged(object sender, EventArgs e)
    {
        drpstanam.DataBind();
        drpstanam.SelectedIndex = 0;
        drpctynam.DataBind();
    }
    
}
