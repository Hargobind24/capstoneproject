using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Collections.Generic;



namespace nsb2b
{
    public interface intcnt
    {
        Int32 cntcod
        {
            get;
            set;
        }
        string cntnam
        {
            get;
            set;
        }
    }
    public interface intsta
    {
        Int32 stacod
        {
            get;
            set;

        }
        string stanam
        {
            get;
            set;
        }
        Int32 stacntcod
        {
            get;
            set;
        }
    }
    public interface intcty
    {
        Int32 ctycod
        {
            get;
            set;
        }
        string ctynam
        {
            get;
            set;
        }
        Int32 ctystacod
        {
            get;
            set;
        }
    }
    public interface intcat
    {
        Int32 catcod
        {
            get;
            set;
        }
        string catnam
        {
            get;
            set;
        }
    }
    public interface intaut
    {
        Int32 autcod
        {
            get;
            set;
        }
        string autnam
        {
            get;
            set;
        }
    }
    public interface intpub
    {
        Int32 pubcod
        {
            get;
            set;
        }
        string pubnam
        {
            get;
            set;
        }
    }
    public interface intsub
    {
        Int32 subcod
        {
            get;
            set;
        }
        string subnam
        {
            get;
            set;
        }
        Int32 subcatcod
        {
            get;
            set;
        }
    }
    public interface intctb
    {
        Int32 ctbcod
        {
            get;
            set;
        }
        string ctbnam
        {
            get;
            set;
        }
    }
    public interface inttit
    {
        Int32 titcod
        {
            get;
            set;
        }
        string titnam
        {
            get;
            set;
        }
        Int32 titsubcod
        {
            get;
            set;
        }
    }
    public interface intbok
    {
        Int32 bokcod
        {
            get;
            set;
        }
        string bokisb
        {
            get;
            set;
        }
        Int32 boktitcod
        {
            get;
            set;
        }
        Int32 bokpubcod
        {
            get;
            set;
        }
        Int32 bokprc
        {
            get;
            set;
        }
        string bokpic
        {
            get;
            set;
        }
        string bokcmt
        {
            get;
            set;
        }
        int boknop
        {
            get;
            set;
        }
        int bokcltcod
        {
            get;
            set;
        }
    }
    public interface intclt
    {
        Int32 cltcod
        {
            get;
            set;
        }
        string cltnam
        {
            get;
            set;
        }
        string cltadd
        {
            get;
            set;
        }
        int cltctycod
        {
            get;
            set;
        }
        string cltphn
        {
            get;
            set;
        }
        string cltpin
        {
            get;
            set;
        }
        string cltfax
        {
            get;
            set;
        }
        string clteml
        {
            get;
            set;
        }
        string clturl
        {
            get;
            set;
        }
        string cltprf
        {
            get;
            set;
        }
        string cltconnam
        {
            get;
            set;
        }
        string cltconphn
        {
            get;
            set;
        }
        string cltconmob
        {
            get;
            set;
        }
        string cltsts
        {
            get;
            set;
        }
        string cltrgn
        {
            get;
            set;
        }
        string cltpic
        {
            get;
            set;
        }
    }
    public interface intbokaut
    {
        Int32 bokautbokcod
        {
            get;
            set;
        }
        Int32 bokautautcod
        {
            get;
            set;
        }

    }
    public interface intusr
    {
        Int32 usrcod
        {
            get;
            set;
        }
        string usrnam
        {
            get;
            set;
        }
        string usrpwd
        {
            get;
            set;
        }
        Int32 usrcltregcod
        {
            get;
            set;
        }
        string usrsts
        {
            get;
            set;
        }
    }
    public interface intcmp
    {
        Int32 cmpcod
        {
            get;
            set;
        }
        string cmpnam
        {
            get;
            set;
        }
        Int32 cmpcltcod
        {
            get;
            set;
        }
    }
    public interface intfet
    {
        Int32 fetcod
        {
            get;
            set;
        }
        string fetnam
        {
            get;
            set;
        }
        Int32 fetcltcod
        {
            get;
            set;
        }
    }
    public interface intmod
    {
        Int32 modcod
        {
            get;
            set;
        }
        string modnum
        {
            get;
            set;
        }
        Int32 modcmpcod
        {
            get;
            set;
        }
        Int32 modcltcod
        {
            get;
            set;
        }
        string moddsc
        {
            get;
            set;
        }
        Int32 modprc
        {
            get;
            set;
        }
        string modpic
        {
            get;
            set;
        }
        Int32 modtehcod
        {
            get;
            set;
        }
    }
    public interface intacc
    {
        Int32 acccod
        {
            get;
            set;
        }
        Int32 acccltcod
        {

            get;
            set;
        }
        string accnam
        {
            get;
            set;
        }
    }
    public interface intmodfet
    {
        Int32 modfetmodcod
        {
            get;
            set;
        }
        Int32 modfetfetcod
        {
            get;
            set;
        }
    }
    public interface intmodacc
    {
        Int32 modaccmodcod
        {
            get;
            set;
        }
        Int32 modaccacccod
        {
            get;
            set;
        }
    }
    public interface intteh
    {
        Int32 tehcod
        {
            get;
            set;
        }
        string tehnam
        {
            get;
            set;
        }
        Int32 tehcltcod
        {
            get;
            set;
        }

    }
    public interface intreg
    {
        Int32 regcod
        {
            get;
            set;
        }
        string regnam
        {
            get;
            set;
        }
        string regadd
        {
            get;
            set;
        }
        string regphn
        {
            get;
            set;
        }
        string regeml
        {
            get;
            set;
        }
        string regpin
        {
            get;
            set;
        }
        string regmob
        {
            get;
            set;
        }
        Int32 regctycod
        {
            get;
            set;
        }
    }
    public interface intord
    {
        Int32 ordcod
        {
            get;
            set;
        }
        DateTime orddat
        {
            get;
            set;
        }
        string orddelnam
        {
            get;
            set;
        }
        string orddeladd
        {
            get;
            set;
        }
        string orddelphn
        {
            get;
            set;
        }
        string orddelmob
        {
            get;
            set;
        }
        char ordsts
        {
            get;
            set;
        }
        Int32 ordregcod
        {
            get;
            set;
        }
        Int32 ordctycod
        {
            get;
            set;
        }
        Int32 ordamt
        {
            get;
            set;
        }

    }
    public interface intorddet
    {
        Int32 orddetordcod
        {
            get;
            set;
        }
        Int32 orddetbokmodcod
        {
            get;
            set;
        }
        Int32 orddetqty
        {
            get;
            set;
        }
    }
    public interface intnewrel
    {
        Int32 newrelbokmodcod
        {
            get;
            set;

        }

    }
    public interface intavl
    {
        Int32 avlbokmodcod
        {
            get;
            set;

        }
        string avldsc
        {
            get;
            set;
        }
    }
    public interface intdis
    {
        Int32 disamt
        {
            get;
            set;
        }
        Int32 disbokmodcod
        {
            get;
            set;
        }
    }
    public class clscntprp : intcnt
    {
        private Int32 ccod;
        private string cnam;

        #region intcnt Members

        public int cntcod
        {
            get
            {
                return ccod;
            }
            set
            {
                ccod = value;
            }
        }

        public string cntnam
        {
            get
            {
                return cnam;
            }
            set
            {
                cnam = value;
            }
        }

        #endregion
    }
    public class clsstaprp : intsta
    {
        private string snam;
        private Int32 scod, scntcod;

        #region intsta Members

        public int stacod
        {
            get
            {
                return scod;

            }
            set
            {
                scod = value;
            }
        }

        public string stanam
        {
            get
            {
                return snam;
            }
            set
            {
                snam = value;
            }
        }

        public int stacntcod
        {
            get
            {
                return scntcod;
            }
            set
            {
                scntcod = value;
            }
        }

        #endregion
    }
    public class clsctyprp : intcty
    {
        private Int32 ccod, cstacod;
        private string cnam;

        #region intcty Members

        public int ctycod
        {
            get
            {
                return ccod;
            }
            set
            {
                ccod = value;
            }
        }

        public string ctynam
        {
            get
            {
                return cnam;
            }
            set
            {
                cnam = value;
            }
        }

        public int ctystacod
        {
            get
            {
                return cstacod;
            }
            set
            {
                cstacod = value;
            }
        }

        #endregion
    }
    public class clscatprp : intcat
    {
        private Int32 ccod;
        private string cnam;


        #region intcat Members

        public int catcod
        {
            get
            {
                return ccod;
            }
            set
            {
                ccod = value;
            }
        }

        public string catnam
        {
            get
            {
                return cnam;
            }
            set
            {
                cnam = value;
            }
        }

        #endregion
    }
    public class clsautprp : intaut
    {
        private Int32 acod;
        private string anam;


        #region intaut Members

        public int autcod
        {
            get
            {
                return acod;
            }
            set
            {
                acod = value;
            }
        }

        public string autnam
        {
            get
            {
                return anam;
            }
            set
            {
                anam = value;
            }
        }

        #endregion
    }
    public class clspubprp : intpub
    {
        private Int32 pcod;
        private string pnam;


        #region intpub Members

        public int pubcod
        {
            get
            {
                return pcod;
            }
            set
            {
                pcod = value;
            }
        }

        public string pubnam
        {
            get
            {
                return pnam;
            }
            set
            {
                pnam = value;
            }
        }

        #endregion
    }
    public class clssubprp : intsub
    {
        private Int32 scod, scatcod;
        private string snam;


        #region intsub Members

        public int subcod
        {
            get
            {
                return scod;
            }
            set
            {
                scod = value;
            }
        }

        public string subnam
        {
            get
            {
                return snam;
            }
            set
            {
                snam = value;
            }
        }

        public int subcatcod
        {
            get
            {
                return scatcod;
            }
            set
            {
                scatcod = value;
            }
        }

        #endregion
    }
    public class clsctbprp : intctb
    {
        private Int32 ccod;
        private string cnam;

        #region intctb Members

        public int ctbcod
        {
            get
            {
                return ccod;
            }
            set
            {
                ccod = value;
            }
        }

        public string ctbnam
        {
            get
            {
                return cnam;
            }
            set
            {
                cnam = value;
            }
        }

        #endregion
    }
    public class clstitprp : inttit
    {
        private string tnam;
        private Int32 tcod, tsubcod;


        #region inttit Members

        public int titcod
        {
            get
            {
                return tcod;
            }
            set
            {
                tcod = value;
            }
        }

        public string titnam
        {
            get
            {
                return tnam;
            }
            set
            {
                tnam = value;
            }
        }

        public int titsubcod
        {
            get
            {
                return tsubcod;

            }
            set
            {
                tsubcod = value;

            }
        }

        #endregion
    }
    public class clsbokprp : intbok
    {
        private Int32 bcod, btitcod, bpubcod, bcltcod, bprc, bnop;
        private string bisb, bpic, bcmt;

        #region intbok Members

        public int bokcod
        {
            get
            {
                return bcod;
            }
            set
            {
                bcod = value;
            }
        }

        public string bokisb
        {
            get
            {
                return bisb;

            }
            set
            {
                bisb = value;
            }
        }

        public int boktitcod
        {
            get
            {
                return btitcod;
            }
            set
            {
                btitcod = value;
            }
        }

        public int bokpubcod
        {
            get
            {
                return bpubcod;

            }
            set
            {
                bpubcod = value;
            }
        }

        public int bokprc
        {
            get
            {
                return bprc;
            }
            set
            {
                bprc = value;
            }
        }

        public string bokpic
        {
            get
            {
                return bpic;

            }
            set
            {
                bpic = value;
            }
        }

        public string bokcmt
        {
            get
            {
                return bcmt;
            }
            set
            {
                bcmt = value;
            }
        }

        public int boknop
        {
            get
            {
                return bnop;
            }
            set
            {
                bnop = value;
            }
        }

        public int bokcltcod
        {
            get
            {
                return bcltcod;
            }
            set
            {
                bcltcod = value;
            }
        }

        #endregion
    }
    public class clscltprp : intclt
    {
        private Int32 ccod, cctycod;
        private string csts, cnam, cadd, cphn, cpin, cfax, ceml, cprf, curl, cconnam, cconphn, cconmob, crgn, cpic;


        #region intclt Members

        public int cltcod
        {
            get
            {
                return ccod;
            }
            set
            {
                ccod = value;
            }
        }

        public string cltnam
        {
            get
            {
                return cnam;
            }
            set
            {
                cnam = value;
            }
        }

        public string cltadd
        {
            get
            {
                return cadd;
            }
            set
            {
                cadd = value;
            }
        }

        public int cltctycod
        {
            get
            {
                return cctycod;
            }
            set
            {
                cctycod = value;
            }
        }

        public string cltphn
        {
            get
            {
                return cphn;
            }
            set
            {
                cphn = value;
            }
        }

        public string cltpin
        {
            get
            {
                return cpin;
            }
            set
            {
                cpin = value;
            }
        }

        public string cltfax
        {
            get
            {
                return cfax;
            }
            set
            {
                cfax = value;
            }
        }

        public string clteml
        {
            get
            {
                return ceml;
            }
            set
            {
                ceml = value;
            }
        }

        public string clturl
        {
            get
            {
                return curl;
            }
            set
            {
                curl = value;
            }
        }
        public string cltpic
        {
            get
            {
                return cpic;
            }
            set
            {
                cpic = value;
            }
        }

        public string cltprf
        {
            get
            {
                return cprf;
            }
            set
            {
                cprf = value;
            }
        }

        public string cltconnam
        {
            get
            {
                return cconnam;
            }
            set
            {
                cconnam = value;
            }
        }

        public string cltconphn
        {
            get
            {
                return cconphn;
            }
            set
            {
                cconphn = value;
            }
        }

        public string cltconmob
        {
            get
            {
                return cconmob;
            }
            set
            {
                cconmob = value;
            }
        }

        public string cltsts
        {
            get
            {
                return csts;
            }
            set
            {
                csts = value;
            }
        }

        public string cltrgn
        {
            get
            {
                return crgn;
            }
            set
            {
                crgn = value;
            }
        }

        #endregion
    }
    public class clsbokautprp : intbokaut
    {
        Int32 babokcod, baautcod;


        #region intbokaut Members

        public int bokautbokcod
        {
            get
            {
                return babokcod;
            }
            set
            {
                babokcod = value;
            }
        }

        public int bokautautcod
        {
            get
            {
                return baautcod;
            }
            set
            {
                baautcod = value;
            }
        }

        #endregion
    }
    public class clsusrprp : intusr
    {
        private Int32 ucod, ucltregcod;
        private string upwd, unam, usts;
        #region intusr Members

        public int usrcod
        {
            get
            {
                return ucod;
            }
            set
            {
                ucod = value;
            }
        }

        public string usrnam
        {
            get
            {
                return unam;
            }
            set
            {
                unam = value;
            }
        }

        public string usrpwd
        {
            get
            {
                return upwd;
            }
            set
            {
                upwd = value;
            }
        }

        public int usrcltregcod
        {
            get
            {
                return ucltregcod;
            }
            set
            {
                ucltregcod = value;
            }
        }

        public string usrsts
        {
            get
            {
                return usts;
            }
            set
            {
                usts = value;
            }
        }

        #endregion
    }
    public class clscmpprp : intcmp
    {
        private Int32 ccod, ccltcod;
        private string cnam;

        #region intcmp Members

        public int cmpcod
        {
            get
            {
                return ccod;
            }

            set
            {
                ccod = value;
            }
        }

        public string cmpnam
        {
            get
            {
                return cnam;
            }
            set
            {
                cnam = value;
            }
        }

        public int cmpcltcod
        {
            get
            {
                return ccltcod;
            }
            set
            {
                ccltcod = value;
            }
        }

        #endregion
    }
    public class clsfetprp : intfet
    {
        private Int32 fcod, fcltcod;
        private string fnam;


        #region intfet Members

        public int fetcod
        {
            get
            {
                return fcod;
            }
            set
            {
                fcod = value;
            }
        }

        public string fetnam
        {
            get
            {
                return fnam;
            }
            set
            {
                fnam = value;
            }
        }

        public int fetcltcod
        {
            get
            {
                return fcltcod;
            }
            set
            {
                fcltcod = value;
            }
        }

        #endregion
    }
    public class clsaccprp : intacc
    {
        private Int32 acod, acltcod;
        private string anam;

        #region intacc Members

        public int acccod
        {
            get
            {
                return acod;
            }
            set
            {
                acod = value;
            }
        }

        public Int32 acccltcod
        {
            get
            {
                return acltcod;
            }
            set
            {
                acltcod = value;
            }
        }

        public string accnam
        {
            get
            {
                return anam;
            }
            set
            {
                anam = value;
            }
        }

        #endregion
    }
    public class clsmodprp : intmod
    {
        private Int32 mcod, mcmpcod, mcltcod, mtehcod, mprc;
        private string mdsc, mpic, mnum;

        #region intmod Members

        public int modcod
        {
            get
            {
                return mcod;
            }
            set
            {
                mcod = value;
            }
        }

        public string modnum
        {
            get
            {
                return mnum;
            }
            set
            {
                mnum = value;
            }
        }

        public int modcmpcod
        {
            get
            {
                return mcmpcod;
            }
            set
            {
                mcmpcod = value;
            }
        }

        public int modcltcod
        {
            get
            {
                return mcltcod;
            }
            set
            {
                mcltcod = value;
            }
        }

        public string moddsc
        {
            get
            {
                return mdsc;
            }
            set
            {
                mdsc = value;
            }
        }

        public int modprc
        {
            get
            {
                return mprc;
            }
            set
            {
                mprc = value;
            }
        }

        public string modpic
        {
            get
            {
                return mpic;
            }
            set
            {
                mpic = value;
            }
        }

        public int modtehcod
        {
            get
            {
                return mtehcod;
            }
            set
            {
                mtehcod = value;
            }
        }

        #endregion
    }
    public class clsmodfetprp : intmodfet
    {
        private Int32 mfmodcod, mffetcod;


        #region intmodfet Members

        public int modfetmodcod
        {
            get
            {
                return mfmodcod;
            }
            set
            {
                mfmodcod = value;
            }
        }

        public int modfetfetcod
        {
            get
            {
                return mffetcod;
            }
            set
            {
                mffetcod = value;

            }
        }

        #endregion
    }
    public class clsmodaccprp : intmodacc
    {
        private Int32 mamodcod, maacccod;

        #region intmodacc Members

        public int modaccmodcod
        {
            get
            {
                return mamodcod;
            }
            set
            {
                mamodcod = value;
            }
        }

        public int modaccacccod
        {
            get
            {
                return maacccod;
            }
            set
            {
                maacccod = value;
            }
        }

        #endregion
    }
    public class clstehprp : intteh
    {

        private Int32 tcod, tcltcod;
        private string tnam;

        #region intteh Members

        public int tehcod
        {
            get
            {
                return tcod;
            }
            set
            {
                tcod = value;
            }
        }

        public string tehnam
        {
            get
            {
                return tnam;
            }
            set
            {
                tnam = value;
            }
        }

        public int tehcltcod
        {
            get
            {
                return tcltcod;
            }
            set
            {
                tcltcod = value;
            }
        }

        #endregion
    }
    public class clsregprp : intreg
    {
        private Int32 rcod, rctycod;
        private string rnam, radd, rphn, reml, rpin, rmob;


        #region intreg Members

        public int regcod
        {
            get
            {
                return rcod;
            }
            set
            {
                rcod = value;
            }
        }

        public string regnam
        {
            get
            {
                return rnam;
            }
            set
            {
                rnam = value;
            }
        }

        public string regadd
        {
            get
            {
                return radd;
            }
            set
            {
                radd = value;
            }
        }

        public string regphn
        {
            get
            {
                return rphn;
            }
            set
            {
                rphn = value;
            }
        }

        public string regeml
        {
            get
            {
                return reml;
            }
            set
            {
                reml = value;
            }
        }

        public string regpin
        {
            get
            {
                return rpin;

            }
            set
            {
                rpin = value;
            }
        }

        public string regmob
        {
            get
            {
                return rmob;
            }
            set
            {
                rmob = value;
            }
        }

        public int regctycod
        {
            get
            {
                return rctycod;
            }
            set
            {
                rctycod = value;

            }
        }

        #endregion
    }
    public class clsordprp : intord
    {
        private Int32 ocod, oregcod, octycod, oamt;
        private string odelnam, odeladd, odelphn, odelmob;
        char osts;
        private DateTime odat;

        #region intord Members

        public int ordcod
        {
            get
            {
                return ocod;
            }
            set
            {
                ocod = value;
            }
        }

        public DateTime orddat
        {
            get
            {
                return odat;
            }
            set
            {
                odat = value;
            }
        }

        public string orddelnam
        {
            get
            {
                return odelnam;
            }
            set
            {
                odelnam = value;
            }
        }
        public string orddeladd
        {
            get
            {
                return odeladd;
            }
            set
            {
                odeladd = value;
            }
        }

        public string orddelphn
        {
            get
            {
                return odelphn;
            }
            set
            {
                odelphn = value;
            }
        }

        public string orddelmob
        {
            get
            {
                return odelmob;
            }
            set
            {
                odelmob = value;

            }
        }

        public char ordsts
        {
            get
            {
                return osts;
            }
            set
            {
                osts = value;

            }
        }

        public int ordregcod
        {
            get
            {
                return oregcod;
            }
            set
            {
                oregcod = value;
            }
        }

        public int ordctycod
        {
            get
            {
                return octycod;
            }
            set
            {
                octycod = value;
            }
        }

        #endregion
    
#region intord Members


public int  ordamt
{
	  get 
	{ 
		return oamt;
	}
	  set 
	{ 
		oamt = value;
	}
}

#endregion
}
    public class clsorddetprp : intorddet
    {
        private Int32 odordcod, odbokmodcod, odqty;

        #region intorddet Members

        public int orddetordcod
        {
            get
            {
                return odordcod;
            }
            set
            {
                odordcod = value;
            }
        }

        public int orddetbokmodcod
        {
            get
            {
                return odbokmodcod;
            }
            set
            {
                odbokmodcod = value;
            }
        }

        public int orddetqty
        {
            get
            {
                return odqty;
            }
            set
            {
                odqty = value;
            }
        }

        #endregion
    }
    public class clsnewrelprp : intnewrel
    {
        private Int32 nrbokmodcod;





        #region intnewrel Members

        public int newrelbokmodcod
        {
            get
            {
                return nrbokmodcod;
            }
            set
            {
                nrbokmodcod = value;
            }
        }

        #endregion
    }
    public class clsdisprp : intdis
    {
        private Int32 dbokmodcod, damt;

        #region intdis Members

        public int disamt
        {
            get
            {
                return damt;
            }
            set
            {
                damt = value;
            }
        }

        public int disbokmodcod
        {
            get
            {
                return dbokmodcod;
            }
            set
            {
                dbokmodcod = value;
            }
        }

        #endregion
    }
    public class clsavlprp : intavl
    {
        private Int32 abokmodcod;
        private string adsc;



        #region intavl Members

        public int avlbokmodcod
        {
            get
            {
                return abokmodcod;
            }
            set
            {
                abokmodcod = value;
            }
        }
        public string avldsc
        {
            get
            {
                return adsc;
            }
            set
            {
                adsc = value;
            }
        }

        #endregion
    }
    public abstract class clscon
    {
        protected SqlConnection con = new SqlConnection();
        public clscon()
        {
            con.ConnectionString = ConfigurationManager.ConnectionStrings["cn"].ConnectionString;

        }
    }
    public class clscnt : clscon
    {
        public void save_rec(clscntprp p)
        {
            if (con.State == ConnectionState.Closed)
            {

                con.Open();
            }
            SqlCommand cmd = new SqlCommand("inscnt", con);
            cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Parameters.Add("@cntcod", SqlDbType.Int).Value = p.cntcod;
            cmd.Parameters.Add("@cntnam", SqlDbType.VarChar, 50).Value = p.cntnam;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public void update_rec(clscntprp p)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("updcnt", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@cntcod", SqlDbType.Int).Value = p.cntcod;
            cmd.Parameters.Add("@cntnam", SqlDbType.VarChar, 50).Value = p.cntnam;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public void delete_rec(clscntprp p)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("delcnt", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@cntcod", SqlDbType.Int).Value = p.cntcod;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public List<clscntprp> display_rec()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("dspcnt", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clscntprp> obj = new List<clscntprp>();
            while (dr.Read())
            {
                clscntprp k = new clscntprp();
                k.cntcod = Convert.ToInt32(dr[0]);
                k.cntnam = dr[1].ToString();
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
        public List<clscntprp> find_rec(Int32 ccod)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("fndcnt", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@cntcod", SqlDbType.Int).Value = ccod;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clscntprp> obj = new List<clscntprp>();
            if (dr.HasRows)
            {
                dr.Read();
                clscntprp k = new clscntprp();
                k.cntcod = Convert.ToInt32(dr[0]);
                k.cntnam = dr[1].ToString();
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
    }
    public class clssta : clscon
    {
        public void save_rec(clsstaprp p)
        {
            if (con.State == ConnectionState.Closed)
            {

                con.Open();
            }
            SqlCommand cmd = new SqlCommand("inssta", con);
            cmd.CommandType = CommandType.StoredProcedure;
            //  cmd.Parameters.Add("@stacod", SqlDbType.Int).Value = p.stacod;
            cmd.Parameters.Add("@stanam", SqlDbType.VarChar, 50).Value = p.stanam;
            cmd.Parameters.Add("@stacntcod", SqlDbType.Int).Value = p.stacntcod;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public void update_rec(clsstaprp p)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("updsta", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@stacod", SqlDbType.Int).Value = p.stacod;
            cmd.Parameters.Add("@stanam", SqlDbType.VarChar, 50).Value = p.stanam;
            cmd.Parameters.Add("@stacntcod", SqlDbType.Int).Value = p.stacntcod;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public void delete_rec(clsstaprp p)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("delsta", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@stacod", SqlDbType.Int).Value = p.stacod;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public List<clsstaprp> display_rec()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("dspsta", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clsstaprp> obj = new List<clsstaprp>();
            while (dr.Read())
            {
                clsstaprp k = new clsstaprp();
                k.stacod = Convert.ToInt32(dr[0]);
                k.stanam = dr[1].ToString();
                k.stacntcod = Convert.ToInt32(dr[2]);
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
        public List<clsstaprp> find_rec(Int32 scod)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("fndsta", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@stacod", SqlDbType.Int).Value = scod;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clsstaprp> obj = new List<clsstaprp>();
            if (dr.HasRows)
            {
                dr.Read();
                clsstaprp k = new clsstaprp();
                k.stacod = Convert.ToInt32(dr[0]);
                k.stanam = dr[1].ToString();
                k.stacntcod = Convert.ToInt32(dr[2]);
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
        public List<clsstaprp> stabycnt(Int32 scntcod)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("stabycnt", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@stacntcod", SqlDbType.Int).Value = scntcod;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clsstaprp> obj = new List<clsstaprp>();
            while (dr.Read())
            {
                clsstaprp k = new clsstaprp();
                k.stacod = Convert.ToInt32(dr[0]);
                k.stanam = dr[1].ToString();
                k.stacntcod = Convert.ToInt32(dr[2]);
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
    }
    public class clscty : clscon
    {
        public void save_rec(clsctyprp p)
        {
            if (con.State == ConnectionState.Closed)
            {

                con.Open();
            }
            SqlCommand cmd = new SqlCommand("inscty", con);
            cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Parameters.Add("@ctycod", SqlDbType.Int).Value = p.ctycod;
            cmd.Parameters.Add("@ctynam", SqlDbType.VarChar, 50).Value = p.ctynam;
            cmd.Parameters.Add("@ctystacod", SqlDbType.Int).Value = p.ctystacod;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public void update_rec(clsctyprp p)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("updcty", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@ctycod", SqlDbType.Int).Value = p.ctycod;
            cmd.Parameters.Add("@ctynam", SqlDbType.VarChar, 50).Value = p.ctynam;
            cmd.Parameters.Add("@ctystacod", SqlDbType.Int).Value = p.ctystacod;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public void delete_rec(clsctyprp p)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("delcty", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@ctycod", SqlDbType.Int).Value = p.ctycod;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public List<clsctyprp> ctybysta(Int32 cstacod)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("ctybysta", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@ctystacod", SqlDbType.Int).Value = cstacod;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clsctyprp> obj = new List<clsctyprp>();
            while (dr.Read())
            {
                clsctyprp k = new clsctyprp();
                k.ctycod = Convert.ToInt32(dr[0]);
                k.ctynam = dr[1].ToString();
                k.ctystacod = Convert.ToInt32(dr[2]);
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
        public List<clsctyprp> display_rec()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("dspcty", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clsctyprp> obj = new List<clsctyprp>();
            while (dr.Read())
            {
                clsctyprp k = new clsctyprp();
                k.ctycod = Convert.ToInt32(dr[0]);
                k.ctynam = dr[1].ToString();
                k.ctystacod = Convert.ToInt32(dr[2]);
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }

        public List<clsctyprp> find_rec(Int32 ccod)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("fndcty", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@ctycod", SqlDbType.Int).Value = ccod;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clsctyprp> obj = new List<clsctyprp>();
            if (dr.HasRows)
            {
                dr.Read();
                clsctyprp k = new clsctyprp();
                k.ctycod = Convert.ToInt32(dr[0]);
                k.ctynam = dr[1].ToString();
                k.ctystacod = Convert.ToInt32(dr[2]);
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
    }
    public class clscat : clscon
    {
        public void save_rec(clscatprp p)
        {
            if (con.State == ConnectionState.Closed)
            {

                con.Open();
            }
            SqlCommand cmd = new SqlCommand("inscat", con);
            cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Parameters.Add("@catcod", SqlDbType.Int).Value = p.catcod;
            cmd.Parameters.Add("@catnam", SqlDbType.VarChar, 50).Value = p.catnam;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public void update_rec(clscatprp p)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("updcat", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@catcod", SqlDbType.Int).Value = p.catcod;
            cmd.Parameters.Add("@catnam", SqlDbType.VarChar, 50).Value = p.catnam;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public void delete_rec(clscatprp p)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("delcat", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@catcod", SqlDbType.Int).Value = p.catcod;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public List<clscatprp> display_rec()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("dspcat", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clscatprp> obj = new List<clscatprp>();
            while (dr.Read())
            {
                clscatprp k = new clscatprp();
                k.catcod = Convert.ToInt32(dr[0]);
                k.catnam = dr[1].ToString();
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
        public List<clscatprp> find_rec(Int32 ccod)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("fndcat", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@catcod", SqlDbType.Int).Value = ccod;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clscatprp> obj = new List<clscatprp>();
            if (dr.HasRows)
            {
                dr.Read();
                clscatprp k = new clscatprp();
                k.catcod = Convert.ToInt32(dr[0]);
                k.catnam = dr[1].ToString();
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }

    }
    public class clsaut : clscon
    {
        public void save_rec(clsautprp p)
        {
            if (con.State == ConnectionState.Closed)
            {

                con.Open();
            }
            SqlCommand cmd = new SqlCommand("insaut", con);
            cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Parameters.Add("@autcod", SqlDbType.Int).Value = p.autcod;
            cmd.Parameters.Add("@autnam", SqlDbType.VarChar, 50).Value = p.autnam;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public void update_rec(clsautprp p)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("updaut", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@autcod", SqlDbType.Int).Value = p.autcod;
            cmd.Parameters.Add("@autnam", SqlDbType.VarChar, 50).Value = p.autnam;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public void delete_rec(clsautprp p)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("delaut", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@autcod", SqlDbType.Int).Value = p.autcod;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public List<clsautprp> display_rec()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("dspaut", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clsautprp> obj = new List<clsautprp>();
            while (dr.Read())
            {
                clsautprp k = new clsautprp();
                k.autcod = Convert.ToInt32(dr[0]);
                k.autnam = dr[1].ToString();
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
        public List<clsautprp> find_rec(Int32 acod)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("fndaut", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@autcod", SqlDbType.Int).Value = acod;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clsautprp> obj = new List<clsautprp>();
            if (dr.HasRows)
            {
                dr.Read();
                clsautprp k = new clsautprp();
                k.autcod = Convert.ToInt32(dr[0]);
                k.autnam = dr[1].ToString();
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
    }
    public class clspub : clscon
    {
        public void save_rec(clspubprp p)
        {
            if (con.State == ConnectionState.Closed)
            {

                con.Open();
            }
            SqlCommand cmd = new SqlCommand("inspub", con);
            cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Parameters.Add("@pubcod", SqlDbType.Int).Value = p.pubcod;
            cmd.Parameters.Add("@pubnam", SqlDbType.VarChar, 50).Value = p.pubnam;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public void update_rec(clspubprp p)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("updpub", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@pubcod", SqlDbType.Int).Value = p.pubcod;
            cmd.Parameters.Add("@pubnam", SqlDbType.VarChar, 50).Value = p.pubnam;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public void delete_rec(clspubprp p)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("delpub", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@pubcod", SqlDbType.Int).Value = p.pubcod;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public List<clspubprp> display_rec()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("dsppub", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clspubprp> obj = new List<clspubprp>();
            while (dr.Read())
            {
                clspubprp k = new clspubprp();
                k.pubcod = Convert.ToInt32(dr[0]);
                k.pubnam = dr[1].ToString();
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
        public List<clspubprp> find_rec(Int32 pcod)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("fndpub", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@pubcod", SqlDbType.Int).Value = pcod;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clspubprp> obj = new List<clspubprp>();
            if (dr.HasRows)
            {
                dr.Read();
                clspubprp k = new clspubprp();
                k.pubcod = Convert.ToInt32(dr[0]);
                k.pubnam = dr[1].ToString();
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
    }
    public class clssub : clscon
    {
        public void save_rec(clssubprp p)
        {
            if (con.State == ConnectionState.Closed)
            {

                con.Open();
            }
            SqlCommand cmd = new SqlCommand("inssub", con);
            cmd.CommandType = CommandType.StoredProcedure;
            //  cmd.Parameters.Add("@subcod", SqlDbType.Int).Value = p.subcod;
            cmd.Parameters.Add("@subnam", SqlDbType.VarChar, 50).Value = p.subnam;
            cmd.Parameters.Add("@subcatcod", SqlDbType.Int).Value = p.subcatcod;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public void update_rec(clssubprp p)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("updsub", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@subcod", SqlDbType.Int).Value = p.subcod;
            cmd.Parameters.Add("@subnam", SqlDbType.VarChar, 50).Value = p.subnam;
            cmd.Parameters.Add("@subcatcod", SqlDbType.Int).Value = p.subcatcod;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public void delete_rec(clssubprp p)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("delsub", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@subcod", SqlDbType.Int).Value = p.subcod;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public List<clssubprp> display_rec()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("dspsub", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clssubprp> obj = new List<clssubprp>();
            while (dr.Read())
            {
                clssubprp k = new clssubprp();
                k.subcod = Convert.ToInt32(dr[0]);
                k.subnam = dr[1].ToString();
                k.subcatcod = Convert.ToInt32(dr[2]);
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
        public List<clssubprp> find_rec(Int32 scod)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("fndsub", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@subcod", SqlDbType.Int).Value = scod;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clssubprp> obj = new List<clssubprp>();
            if (dr.HasRows)
            {
                dr.Read();
                clssubprp k = new clssubprp();
                k.subcod = Convert.ToInt32(dr[0]);
                k.subnam = dr[1].ToString();
                k.subcatcod = Convert.ToInt32(dr[2]);
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
        public List<clssubprp> subbycat(Int32 scatcod)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("subbycat", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@subcatcod", SqlDbType.Int).Value = scatcod;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clssubprp> obj = new List<clssubprp>();
            while (dr.Read())
            {
                clssubprp k = new clssubprp();
                k.subcod = Convert.ToInt32(dr[0]);
                k.subnam = dr[1].ToString();
                k.subcatcod = Convert.ToInt32(dr[2]);
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
    }
    public class clsctb : clscon
    {
        public void save_rec(clsctbprp p)
        {
            if (con.State == ConnectionState.Closed)
            {

                con.Open();
            }
            SqlCommand cmd = new SqlCommand("insctb", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@ctbcod", SqlDbType.Int).Value = p.ctbcod;
            cmd.Parameters.Add("@ctbnam", SqlDbType.VarChar, 50).Value = p.ctbnam;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public void update_rec(clsctbprp p)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("updctb", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@ctbcod", SqlDbType.Int).Value = p.ctbcod;
            cmd.Parameters.Add("@ctbnam", SqlDbType.VarChar, 50).Value = p.ctbnam;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public void delete_rec(clsctbprp p)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("delctb", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@ctbcod", SqlDbType.Int).Value = p.ctbcod;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public List<clsctbprp> display_rec()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("dspctb", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clsctbprp> obj = new List<clsctbprp>();
            while (dr.Read())
            {
                clsctbprp k = new clsctbprp();
                k.ctbcod = Convert.ToInt32(dr[0]);
                k.ctbnam = dr[1].ToString();
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
        public List<clsctbprp> find_rec(Int32 ccod)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("fndctb", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@ctbcod", SqlDbType.Int).Value = ccod;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clsctbprp> obj = new List<clsctbprp>();
            if (dr.HasRows)
            {
                dr.Read();
                clsctbprp k = new clsctbprp();
                k.ctbcod = Convert.ToInt32(dr[0]);
                k.ctbnam = dr[1].ToString();
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
    }
    public class clstit : clscon
    {
        public void save_rec(clstitprp p)
        {
            if (con.State == ConnectionState.Closed)
            {

                con.Open();
            }
            SqlCommand cmd = new SqlCommand("instit", con);
            cmd.CommandType = CommandType.StoredProcedure;
            // cmd.Parameters.Add("@titcod", SqlDbType.Int).Value = p.titcod;
            cmd.Parameters.Add("@titnam", SqlDbType.VarChar, 50).Value = p.titnam;
            cmd.Parameters.Add("@titsubcod", SqlDbType.Int).Value = p.titsubcod;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public void update_rec(clstitprp p)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("updtit", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@titcod", SqlDbType.Int).Value = p.titcod;
            cmd.Parameters.Add("@titnam", SqlDbType.VarChar, 50).Value = p.titnam;
            cmd.Parameters.Add("@titsubcod", SqlDbType.Int).Value = p.titsubcod;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public void delete_rec(clstitprp p)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("deltit", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@titcod", SqlDbType.Int).Value = p.titcod;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public List<clstitprp> display_rec()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("dsptit", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clstitprp> obj = new List<clstitprp>();
            while (dr.Read())
            {
                clstitprp k = new clstitprp();
                k.titcod = Convert.ToInt32(dr[0]);
                k.titnam = dr[1].ToString();
                k.titsubcod = Convert.ToInt32(dr[2]);
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
        public List<clstitprp> find_rec(Int32 tcod)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("fndtit", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@titcod", SqlDbType.Int).Value = tcod;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clstitprp> obj = new List<clstitprp>();
            if (dr.HasRows)
            {
                dr.Read();
                clstitprp k = new clstitprp();
                k.titcod = Convert.ToInt32(dr[0]);
                k.titnam = dr[1].ToString();
                k.titsubcod = Convert.ToInt32(dr[2]);
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }

        public List<clstitprp> titbysub(Int32 tsubcod)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("titbysub", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@titsubcod", SqlDbType.Int).Value = tsubcod;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clstitprp> obj = new List<clstitprp>();
            while (dr.Read())
            {
                clstitprp k = new clstitprp();
                k.titcod = Convert.ToInt32(dr[0]);
                k.titnam = dr[1].ToString();
                k.titsubcod = Convert.ToInt32(dr[2]);
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
    }
    public class clsbokaut : clscon
    {
        public void save_rec(clsbokautprp p)
        {
            if (con.State == ConnectionState.Closed)
            {

                con.Open();
            }
            SqlCommand cmd = new SqlCommand("insbokaut", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@bokautbokcod", SqlDbType.Int).Value = p.bokautbokcod;
            cmd.Parameters.Add("@bokautautcod", SqlDbType.Int).Value = p.bokautautcod;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public void update_rec(clsbokautprp p)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("updbokaut", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@bokautbokcod", SqlDbType.Int).Value = p.bokautbokcod;
            cmd.Parameters.Add("@bokautautcod", SqlDbType.Int).Value = p.bokautautcod;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public void delete_rec(clsbokautprp p)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("delbokaut", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@bokautbokcod", SqlDbType.Int).Value = p.bokautbokcod;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public List<clsbokautprp> display_rec()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("dspbokaut", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clsbokautprp> obj = new List<clsbokautprp>();
            while (dr.Read())
            {
                clsbokautprp k = new clsbokautprp();
                k.bokautbokcod = Convert.ToInt32(dr[0]);
                k.bokautautcod = Convert.ToInt32(dr[1]);
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
        public List<clsbokautprp> find_rec(Int32 babokcod)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("fndbokaut", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@bokautbokcod", SqlDbType.Int).Value = babokcod;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clsbokautprp> obj = new List<clsbokautprp>();
            if (dr.HasRows)
            {
                dr.Read();
                clsbokautprp k = new clsbokautprp();
                k.bokautbokcod = Convert.ToInt32(dr[0]);
                k.bokautautcod = Convert.ToInt32(dr[1]);
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
    }
    public class clscmp : clscon
    {
        public void save_rec(clscmpprp p)
        {
            if (con.State == ConnectionState.Closed)
            {

                con.Open();
            }
            SqlCommand cmd = new SqlCommand("inscmp", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@cmpcod", SqlDbType.Int).Value = p.cmpcod;
            cmd.Parameters.Add("@cmpnam", SqlDbType.VarChar, 50).Value = p.cmpnam;
            cmd.Parameters.Add("@cmpcltcod", SqlDbType.Int).Value = p.cmpcltcod;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public void update_rec(clscmpprp p)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("updcmp", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@cmpcod", SqlDbType.Int).Value = p.cmpcod;
            cmd.Parameters.Add("@cmpnam", SqlDbType.VarChar, 50).Value = p.cmpnam;
            cmd.Parameters.Add("@cmpcltcod", SqlDbType.Int).Value = p.cmpcltcod;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public void delete_rec(clscmpprp p)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("delcmp", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@cmpcod", SqlDbType.Int).Value = p.cmpcod;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public List<clscmpprp> display_rec()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("dspcmp", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clscmpprp> obj = new List<clscmpprp>();
            while (dr.Read())
            {
                clscmpprp k = new clscmpprp();
                k.cmpcod = Convert.ToInt32(dr[0]);
                k.cmpnam = dr[1].ToString();
                k.cmpcltcod = Convert.ToInt32(dr[2]);
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
        public List<clscmpprp> find_rec(Int32 ccod)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("fndcmp", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@cmpcod", SqlDbType.Int).Value = ccod;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clscmpprp> obj = new List<clscmpprp>();
            if (dr.HasRows)
            {
                dr.Read();
                clscmpprp k = new clscmpprp();
                k.cmpcod = Convert.ToInt32(dr[0]);
                k.cmpnam = dr[1].ToString();
                k.cmpcltcod = Convert.ToInt32(dr[2]);
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
    }
    public class clsbok : clscon
    {
        public List<clsbokprp> dispbokbyclttit(Int32 ccod,Int32 titcod)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("dspbokbyclttit", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@bokcltcod", SqlDbType.Int).Value = ccod;
            cmd.Parameters.Add("@boktitcod", SqlDbType.Int).Value = titcod;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clsbokprp> obj = new List<clsbokprp>();
            while (dr.Read())
            {
                clsbokprp k = new clsbokprp();
                k.bokcod = Convert.ToInt32(dr[0]);
                k.bokisb = dr[1].ToString();
                k.boktitcod = Convert.ToInt32(dr[2]);
                k.bokpubcod = Convert.ToInt32(dr[3]);
                k.bokprc = Convert.ToInt32(dr[4]);
                k.bokpic = dr[5].ToString();
                k.bokcmt = dr[6].ToString();
                k.boknop = Convert.ToInt32(dr[7]);
                k.bokcltcod = Convert.ToInt32(dr[8]);
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
        public Int32 getauto()
        {
            if (con.State == ConnectionState.Closed)
            {

                con.Open();
            }
            SqlCommand cmd = new SqlCommand("select isnull(max(bokcod),0) from tbbok");
            cmd.Connection = con;
            Int32 i = Convert.ToInt32(cmd.ExecuteScalar()) + 1;
            return i;
        }
        public void save_rec(clsbokprp p)
        {
            if (con.State == ConnectionState.Closed)
            {

                con.Open();
            }
            SqlCommand cmd = new SqlCommand("insbok", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@bokcod", SqlDbType.Int).Value = p.bokcod;
            cmd.Parameters.Add("@bokisb", SqlDbType.VarChar, 50).Value = p.bokisb;
            cmd.Parameters.Add("@boktitcod", SqlDbType.Int).Value = p.boktitcod;
            cmd.Parameters.Add("@bokpubcod", SqlDbType.Int).Value = p.bokpubcod;
            cmd.Parameters.Add("@bokprc", SqlDbType.Int).Value = p.bokprc;
            cmd.Parameters.Add("@bokcltcod", SqlDbType.Int).Value = p.bokcltcod;
            cmd.Parameters.Add("@bokpic", SqlDbType.VarChar, 50).Value = p.bokpic;
            cmd.Parameters.Add("@bokcmt", SqlDbType.VarChar, 200).Value = p.bokcmt;
            cmd.Parameters.Add("@boknop", SqlDbType.Int).Value = p.boknop;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public void update_rec(clsbokprp p)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("updbok", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@bokcod", SqlDbType.Int).Value = p.bokcod;
            cmd.Parameters.Add("@bokisb", SqlDbType.VarChar, 50).Value = p.bokisb;
            cmd.Parameters.Add("@boktitcod", SqlDbType.Int).Value = p.boktitcod;
            cmd.Parameters.Add("@bokpubcod", SqlDbType.Int).Value = p.bokpubcod;
            cmd.Parameters.Add("@bokprc", SqlDbType.Int).Value = p.bokprc;
            cmd.Parameters.Add("@bokcltcod", SqlDbType.Int).Value = p.bokcltcod;
            cmd.Parameters.Add("@bokpic", SqlDbType.VarChar, 50).Value = p.bokpic;
            cmd.Parameters.Add("@bokcmt", SqlDbType.VarChar, 200).Value = p.bokcmt;
            cmd.Parameters.Add("@boknop", SqlDbType.Int).Value = p.boknop;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public void delete_rec(clsbokprp p)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("delbok", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@bokcod", SqlDbType.Int).Value = p.bokcod;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public List<clsbokprp> display_rec()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("dspbok", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clsbokprp> obj = new List<clsbokprp>();
            while (dr.Read())
            {
                clsbokprp k = new clsbokprp();
                k.bokcod = Convert.ToInt32(dr[0]);
                k.bokisb = dr[1].ToString();
                k.boktitcod = Convert.ToInt32(dr[2]);
                k.bokpubcod = Convert.ToInt32(dr[3]);
                k.bokprc = Convert.ToInt32(dr[4]);
                k.bokpic = dr[5].ToString();
                k.bokcmt = dr[6].ToString();
                k.boknop = Convert.ToInt32(dr[7]);
                k.bokcltcod = Convert.ToInt32(dr[8]);
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
        public List<clsbokprp> find_rec(Int32 bcod,out List<clsautprp> aa)
        {
            aa = new List<clsautprp>();
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("fndbok", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@bokcod", SqlDbType.Int).Value = bcod;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clsbokprp> obj = new List<clsbokprp>();
            if (dr.HasRows)
            {
                dr.Read();
                clsbokprp k = new clsbokprp();
                k.bokcod = Convert.ToInt32(dr[0]);
                k.bokisb = dr[1].ToString();
                k.boktitcod = Convert.ToInt32(dr[2]);
                k.bokpubcod = Convert.ToInt32(dr[3]);
                k.bokprc = Convert.ToInt32(dr[4]);
                k.bokpic = dr[5].ToString();
                k.bokcmt = dr[6].ToString();
                k.boknop = Convert.ToInt32(dr[7]);
                k.bokcltcod = Convert.ToInt32(dr[8]);
                obj.Add(k);
                dr.NextResult();
                while (dr.Read())
                {
                    clsautprp a = new clsautprp();
                    a.autcod = Convert.ToInt32(dr[0]);
                    a.autnam = dr[1].ToString();
                    aa.Add(a);
                }
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
    }
    public class clsclt : clscon
    {
        public void save_rec(clscltprp p)
        {
            if (con.State == ConnectionState.Closed)
            {

                con.Open();
            }
            SqlCommand cmd = new SqlCommand("insclt", con);
            cmd.CommandType = CommandType.StoredProcedure;
            //  cmd.Parameters.Add("@cltcod", SqlDbType.Int).Value = p.cltcod;
            cmd.Parameters.Add("@cltnam", SqlDbType.VarChar, 50).Value = p.cltnam;
            cmd.Parameters.Add("@cltadd", SqlDbType.VarChar, 200).Value = p.cltadd;
            cmd.Parameters.Add("@cltctycod", SqlDbType.Int).Value = p.cltctycod;
            cmd.Parameters.Add("@cltphn", SqlDbType.VarChar, 50).Value = p.cltphn;
            cmd.Parameters.Add("@cltpin", SqlDbType.VarChar, 50).Value = p.cltpin;
            cmd.Parameters.Add("@cltfax", SqlDbType.VarChar, 50).Value = p.cltfax;
            cmd.Parameters.Add("@clteml", SqlDbType.VarChar, 50).Value = p.clteml;
            cmd.Parameters.Add("@clturl", SqlDbType.VarChar, 50).Value = p.clturl;
            cmd.Parameters.Add("@cltprf", SqlDbType.VarChar, 200).Value = p.cltprf;
            cmd.Parameters.Add("@cltconnam", SqlDbType.VarChar, 50).Value = p.cltconnam;
            cmd.Parameters.Add("@cltconphn", SqlDbType.VarChar, 50).Value = p.cltconphn;
            cmd.Parameters.Add("@cltsts", SqlDbType.VarChar, 50).Value = p.cltsts;
            cmd.Parameters.Add("@cltrgn", SqlDbType.VarChar, 50).Value = p.cltrgn;
            cmd.Parameters.Add("@cltconmob", SqlDbType.VarChar, 50).Value = p.cltconmob;
            cmd.Parameters.Add("@cltpic", SqlDbType.VarChar, 50).Value = p.cltpic;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public void update_rec(clscltprp p)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("updclt", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@cltcod", SqlDbType.Int).Value = p.cltcod;
            cmd.Parameters.Add("@cltnam", SqlDbType.VarChar, 50).Value = p.cltnam;
            cmd.Parameters.Add("@cltadd", SqlDbType.VarChar, 200).Value = p.cltadd;
            cmd.Parameters.Add("@cltctycod", SqlDbType.Int).Value = p.cltctycod;
            cmd.Parameters.Add("@cltphn", SqlDbType.VarChar, 50).Value = p.cltphn;
            cmd.Parameters.Add("@cltpin", SqlDbType.VarChar, 50).Value = p.cltpin;
            cmd.Parameters.Add("@cltfax", SqlDbType.VarChar, 50).Value = p.cltfax;
            cmd.Parameters.Add("@clteml", SqlDbType.VarChar, 50).Value = p.clteml;
            cmd.Parameters.Add("@clturl", SqlDbType.VarChar, 50).Value = p.clturl;
            cmd.Parameters.Add("@cltprf", SqlDbType.VarChar, 200).Value = p.cltprf;
            cmd.Parameters.Add("@cltconnam", SqlDbType.VarChar, 50).Value = p.cltconnam;
            cmd.Parameters.Add("@cltconphn", SqlDbType.VarChar, 50).Value = p.cltconphn;
            cmd.Parameters.Add("@cltsts", SqlDbType.VarChar, 50).Value = p.cltsts;
            cmd.Parameters.Add("@cltrgn", SqlDbType.VarChar, 50).Value = p.cltrgn;
            cmd.Parameters.Add("@cltconmob", SqlDbType.VarChar, 50).Value = p.cltconmob;
            cmd.Parameters.Add("@cltpic", SqlDbType.VarChar, 50).Value = p.cltpic;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public void updatests_rec(clscltprp p)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("updcltsts", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@cltcod", SqlDbType.Int).Value = p.cltcod;
            cmd.Parameters.Add("@cltsts", SqlDbType.VarChar, 50).Value = p.cltsts;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public void delete_rec(clscltprp p)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("delclt", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@cltcod", SqlDbType.Int).Value = p.cltcod;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
        public List<clscltprp> display_rec()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("dspclt", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clscltprp> obj = new List<clscltprp>();
            while (dr.Read())
            {
                clscltprp k = new clscltprp();
                k.cltcod = Convert.ToInt32(dr[0]);
                k.cltnam = dr["cltnam"].ToString();
                k.cltadd = dr["cltadd"].ToString();
                k.cltctycod = Convert.ToInt32(dr["cltctycod"]);
                k.cltphn = dr["cltphn"].ToString();
                k.cltpin = dr["cltpin"].ToString();
                k.cltfax = dr["cltfax"].ToString();
                k.clteml = dr["clteml"].ToString();
                k.clturl = dr["clturl"].ToString();
                k.cltprf = dr["cltprf"].ToString();
                k.cltpic = dr["cltpic"].ToString();
                k.cltconnam = dr["cltconnam"].ToString();
                k.cltconphn = dr["cltconphn"].ToString();
                k.cltconmob = dr["cltconmob"].ToString();
                k.cltsts = dr["cltsts"].ToString();
                k.cltrgn = dr["cltrgn"].ToString();
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
        public List<clscltprp> displayforver_rec()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("dspcltver", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clscltprp> obj = new List<clscltprp>();
            while (dr.Read())
            {
                clscltprp k = new clscltprp();
                k.cltcod = Convert.ToInt32(dr[0]);
                k.cltnam = dr["cltnam"].ToString();
                k.cltadd = dr["cltadd"].ToString();
                k.cltctycod = Convert.ToInt32(dr["cltctycod"]);
                k.cltphn = dr["cltphn"].ToString();
                k.cltpin = dr["cltpin"].ToString();
                k.cltfax = dr["cltfax"].ToString();
                k.clteml = dr["clteml"].ToString();
                k.clturl = dr["clturl"].ToString();
                k.cltprf = dr["cltprf"].ToString();
                k.cltpic = dr["cltpic"].ToString();
                k.cltconnam = dr["cltconnam"].ToString();
                k.cltconphn = dr["cltconphn"].ToString();
                k.cltconmob = dr["cltconmob"].ToString();
                k.cltsts = dr["cltsts"].ToString();
                k.cltrgn = dr["cltrgn"].ToString();
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
        public List<clscltprp> find_rec(Int32 ccod)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("fndclt", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@cltcod", SqlDbType.Int).Value = ccod;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clscltprp> obj = new List<clscltprp>();
            if (dr.HasRows)
            {
                dr.Read();
                clscltprp k = new clscltprp();
                k.cltcod = Convert.ToInt32(dr[0]);
                k.cltnam = dr["cltnam"].ToString();
                k.cltadd = dr["cltadd"].ToString();
                k.cltctycod = Convert.ToInt32(dr["cltctycod"]);
                k.cltphn = dr["cltphn"].ToString();
                k.cltpin = dr["cltpin"].ToString();
                k.cltfax = dr["cltfax"].ToString();
                k.clteml = dr["clteml"].ToString();
                k.clturl = dr["clturl"].ToString();
                k.cltprf = dr["cltprf"].ToString();
                k.cltpic = dr["cltpic"].ToString();
                k.cltconnam = dr["cltconnam"].ToString();
                k.cltconphn = dr["cltconphn"].ToString();
                k.cltconmob = dr["cltconmob"].ToString();
                k.cltsts = dr["cltsts"].ToString();
                k.cltrgn = dr["cltrgn"].ToString();
                obj.Add(k);
            }
            dr.Close();
            cmd.Dispose();
            con.Close();
            return obj;
        }
    }
	public class clsusr : clscon
	{
		public void save_rec(clsusrprp p)
		{
			if (con.State == ConnectionState.Closed)
			{

				con.Open();
			}
			SqlCommand cmd = new SqlCommand("insusr", con);
			cmd.CommandType = CommandType.StoredProcedure;
			// cmd.Parameters.Add("@usrcod", SqlDbType.Int).Value = p.usrcod;
			cmd.Parameters.Add("@usrnam", SqlDbType.VarChar, 50).Value = p.usrnam;
			cmd.Parameters.Add("@usrpwd", SqlDbType.VarChar, 50).Value = p.usrpwd;
			cmd.Parameters.Add("@usrcltregcod", SqlDbType.Int).Value = p.usrcltregcod;
			cmd.Parameters.Add("@usrsts", SqlDbType.Char, 1).Value = p.usrsts;
			cmd.ExecuteNonQuery();
			cmd.Dispose();
			con.Close();
		}
		public void update_rec(clsusrprp p)
		{
			if (con.State == ConnectionState.Closed)
			{
				con.Open();
			}
			SqlCommand cmd = new SqlCommand("updusr", con);
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.Parameters.Add("@usrcod", SqlDbType.Int).Value = p.usrcod;
			cmd.Parameters.Add("@usrnam", SqlDbType.VarChar, 50).Value = p.usrnam;
			cmd.Parameters.Add("@usrpwd", SqlDbType.VarChar, 50).Value = p.usrpwd;
			cmd.Parameters.Add("@usrcltregcod", SqlDbType.Int).Value = p.usrcltregcod;
			cmd.Parameters.Add("@usrsts", SqlDbType.Char, 1).Value = p.usrsts;
			cmd.ExecuteNonQuery();
			cmd.Dispose();
			con.Close();
		}
		public void delete_rec(clsusrprp p)
		{
			if (con.State == ConnectionState.Closed)
			{
				con.Open();
			}
			SqlCommand cmd = new SqlCommand("delusr", con);
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.Parameters.Add("@usrcod", SqlDbType.Int).Value = p.usrcod;
			cmd.ExecuteNonQuery();
			cmd.Dispose();
			con.Close();
		}
		public List<clsusrprp> display_rec()
							   {
								   if (con.State == ConnectionState.Closed)
								   {
									   con.Open();
								   }
								   SqlCommand cmd = new SqlCommand("dspusr", con);
								   cmd.CommandType = CommandType.StoredProcedure;
								   SqlDataReader dr;
								   dr = cmd.ExecuteReader();
								   List<clsusrprp> obj = new List<clsusrprp>();
									   while (dr.Read())
									   {
										   clsusrprp k = new clsusrprp();
										   k.usrcod = Convert.ToInt32(dr[0]);
										   k.usrnam = dr[1].ToString();
										   k.usrpwd = dr[2].ToString();
										   k.usrcltregcod = Convert.ToInt32(dr[3]);
										   k.usrsts = dr[4].ToString();
										   obj.Add(k);
									   }
								   dr.Close();
								   cmd.Dispose();
								   con.Close();
								   return obj;
							   }
		public List<clsusrprp> find_rec(Int32 ucod)
							   {
								   if (con.State == ConnectionState.Closed)
								   {
									   con.Open();
								   }
								   SqlCommand cmd = new SqlCommand("fndusr", con);
								   cmd.CommandType = CommandType.StoredProcedure;
								   cmd.Parameters.Add("@usrcod", SqlDbType.Int).Value = ucod;
								   SqlDataReader dr;
								   dr = cmd.ExecuteReader();
								   List<clsusrprp> obj = new List<clsusrprp>();
									   if (dr.HasRows)
									   {
										   dr.Read();
										   clsusrprp k = new clsusrprp();
										   k.usrcod = Convert.ToInt32(dr[0]);
										   k.usrnam = dr[1].ToString();
										   k.usrpwd = dr[2].ToString();
										   k.usrcltregcod = Convert.ToInt32(dr[3]);
										   k.usrsts = dr[4].ToString();
										   obj.Add(k);
									   }
								   dr.Close();
								   cmd.Dispose();
								   con.Close();
								   return obj;
							   }
		public Int32 checkuser(string u, string p)
		{
			if (con.State == ConnectionState.Closed)
			{

				con.Open();
			}
			SqlCommand cmd = new SqlCommand();
			cmd.CommandText = "logincheck";
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.Connection = con;
			cmd.Parameters.Add("@u", SqlDbType.VarChar, 50).Value = u;
			cmd.Parameters.Add("@p", SqlDbType.VarChar, 50).Value = p;
			SqlParameter p1 = new SqlParameter("@ret", SqlDbType.Int);
			p1.Direction = ParameterDirection.ReturnValue;
			cmd.Parameters.Add(p1);
			cmd.ExecuteNonQuery();
			Int32 r = Convert.ToInt32(cmd.Parameters["@ret"].Value);
			cmd.Dispose();
			con.Close();
			return r;

		}
	}

        public class clsfet : clscon
        {
            public void save_rec(clsfetprp p)
            {
                if (con.State == ConnectionState.Closed)
                {

                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("insfet", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@fetcod", SqlDbType.Int).Value = p.fetcod;
                cmd.Parameters.Add("@fetnam", SqlDbType.VarChar, 50).Value = p.fetnam;
                cmd.Parameters.Add("@fetcltcod", SqlDbType.Int).Value = p.fetcltcod;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public void update_rec(clsfetprp p)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("updfet", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@fetcod", SqlDbType.Int).Value = p.fetcod;
                cmd.Parameters.Add("@fetnam", SqlDbType.VarChar, 50).Value = p.fetnam;
                cmd.Parameters.Add("@fetcltcod", SqlDbType.Int).Value = p.fetcltcod;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public void delete_rec(clsfetprp p)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("delfet", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@fetcod", SqlDbType.Int).Value = p.fetcod;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public List<clsfetprp> display_rec()
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("dspfet", con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                List<clsfetprp> obj = new List<clsfetprp>();
                while (dr.Read())
                {
                    clsfetprp k = new clsfetprp();
                    k.fetcod = Convert.ToInt32(dr[0]);
                    k.fetnam = dr[1].ToString();
                    k.fetcltcod = Convert.ToInt32(dr[2]);
                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();
                return obj;
            }
            public List<clsfetprp> find_rec(Int32 fcod)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("fndfet", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@fetcod", SqlDbType.Int).Value = fcod;
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                List<clsfetprp> obj = new List<clsfetprp>();
                if (dr.HasRows)
                {
                    dr.Read();
                    clsfetprp k = new clsfetprp();
                    k.fetcod = Convert.ToInt32(dr[0]);
                    k.fetnam = dr[1].ToString();
                    k.fetcltcod = Convert.ToInt32(dr[2]);
                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();
                return obj;
            }
        }
        public class clsacc : clscon
        {
            public void save_rec(clsaccprp p)
            {
                if (con.State == ConnectionState.Closed)
                {

                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("insacc", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@acccod", SqlDbType.Int).Value = p.acccod;
                cmd.Parameters.Add("@accnam", SqlDbType.VarChar, 50).Value = p.accnam;
                cmd.Parameters.Add("@acccltcod", SqlDbType.Int).Value = p.acccltcod;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public void update_rec(clsaccprp p)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("updacc", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@acccod", SqlDbType.Int).Value = p.acccod;
                cmd.Parameters.Add("@accnam", SqlDbType.VarChar, 50).Value = p.accnam;
                cmd.Parameters.Add("@acccltcod", SqlDbType.Int).Value = p.acccltcod;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public void delete_rec(clsaccprp p)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("delacc", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@acccod", SqlDbType.Int).Value = p.acccod;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public List<clsaccprp> display_rec()
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("dspacc", con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                List<clsaccprp> obj = new List<clsaccprp>();
                while (dr.Read())
                {
                    clsaccprp k = new clsaccprp();
                    k.acccod = Convert.ToInt32(dr[0]);
                    k.accnam = dr[1].ToString();
                    k.acccltcod = Convert.ToInt32(dr[2]);
                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();
                return obj;
            }
            public List<clsaccprp> find_rec(Int32 acod)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("fndacc", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@acccod", SqlDbType.Int).Value = acod;
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                List<clsaccprp> obj = new List<clsaccprp>();
                if (dr.HasRows)
                {
                    dr.Read();
                    clsaccprp k = new clsaccprp();
                    k.acccod = Convert.ToInt32(dr[0]);
                    k.accnam = dr[1].ToString();
                    k.acccltcod = Convert.ToInt32(dr[2]);
                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();
                return obj;
            }
        }
        public class clsmod : clscon
        {
            public void save_rec(clsmodprp p)
            {
                if (con.State == ConnectionState.Closed)
                {

                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("insmod", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@modcod", SqlDbType.Int).Value = p.modcod;
                cmd.Parameters.Add("@modnum", SqlDbType.VarChar, 50).Value = p.modnum;
                cmd.Parameters.Add("@modcmpcod", SqlDbType.Int).Value = p.modcmpcod;
                cmd.Parameters.Add("@moddsc", SqlDbType.VarChar, 50).Value = p.moddsc;
                cmd.Parameters.Add("@modpic", SqlDbType.VarChar, 50).Value = p.modpic;
                cmd.Parameters.Add("@modtehcod", SqlDbType.Int).Value = p.modtehcod;
                cmd.Parameters.Add("@modcltcod", SqlDbType.Int).Value = p.modcltcod;
                cmd.Parameters.Add("@modprc", SqlDbType.Int).Value = p.modprc;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public void update_rec(clsmodprp p)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("updmod", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@modcod", SqlDbType.Int).Value = p.modcod;
                cmd.Parameters.Add("@modnum", SqlDbType.VarChar, 50).Value = p.modnum;
                cmd.Parameters.Add("@modcmpcod", SqlDbType.Int).Value = p.modcmpcod;
                cmd.Parameters.Add("@moddsc", SqlDbType.VarChar, 50).Value = p.moddsc;
                cmd.Parameters.Add("@modpic", SqlDbType.VarChar, 50).Value = p.modpic;
                cmd.Parameters.Add("@modtehcod", SqlDbType.Int).Value = p.modtehcod;
                cmd.Parameters.Add("@modcltcod", SqlDbType.Int).Value = p.modcltcod;
                cmd.Parameters.Add("@modprc", SqlDbType.Int).Value = p.modprc;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public void delete_rec(clsmodprp p)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("delmod", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@modcod", SqlDbType.Int).Value = p.modcod;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public List<clsmodprp> display_rec()
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("dspmod", con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                List<clsmodprp> obj = new List<clsmodprp>();
                while (dr.Read())
                {
                    clsmodprp k = new clsmodprp();
                    k.modcod = Convert.ToInt32(dr[0]);
                    k.modnum = dr[1].ToString();
                    k.modcmpcod = Convert.ToInt32(dr[2]);
                    k.moddsc = dr[3].ToString();
                    k.modprc = Convert.ToInt32(dr[4]);
                    k.modpic = dr[5].ToString();
                    k.modtehcod = Convert.ToInt32(dr[6]);
                    k.modcltcod = Convert.ToInt32(dr[7]);
                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();
                return obj;
            }
            public List<clsmodprp> find_rec(Int32 mcod)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("fndmod", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@modcod", SqlDbType.Int).Value = mcod;
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                List<clsmodprp> obj = new List<clsmodprp>();
                if (dr.HasRows)
                {
                    dr.Read();
                    clsmodprp k = new clsmodprp();
                    k.modcod = Convert.ToInt32(dr[0]);
                    k.modnum = dr[1].ToString();
                    k.modcmpcod = Convert.ToInt32(dr[2]);
                    k.moddsc = dr[3].ToString();
                    k.modprc = Convert.ToInt32(dr[4]);
                    k.modpic = dr[5].ToString();
                    k.modtehcod = Convert.ToInt32(dr[6]);
                    k.modcltcod = Convert.ToInt32(dr[7]);
                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();
                return obj;
            }
        }
        public class clsteh : clscon
        {
            public void save_rec(clstehprp p)
            {
                if (con.State == ConnectionState.Closed)
                {

                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("insteh", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@tehcod", SqlDbType.Int).Value = p.tehcod;
                cmd.Parameters.Add("@tehnam", SqlDbType.VarChar, 50).Value = p.tehnam;
                cmd.Parameters.Add("@tehcltcod", SqlDbType.Int).Value = p.tehcltcod;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public void update_rec(clstehprp p)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("updteh", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@tehcod", SqlDbType.Int).Value = p.tehcod;
                cmd.Parameters.Add("@tehnam", SqlDbType.VarChar, 50).Value = p.tehnam;
                cmd.Parameters.Add("@tehcltcod", SqlDbType.Int).Value = p.tehcltcod;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public void delete_rec(clstehprp p)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("delteh", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@tehcod", SqlDbType.Int).Value = p.tehcod;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public List<clstehprp> display_rec()
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("dspteh", con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                List<clstehprp> obj = new List<clstehprp>();
                while (dr.Read())
                {
                    clstehprp k = new clstehprp();
                    k.tehcod = Convert.ToInt32(dr[0]);
                    k.tehnam = dr[1].ToString();
                    k.tehcltcod = Convert.ToInt32(dr[2]);
                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();
                return obj;
            }
            public List<clstehprp> find_rec(Int32 tcod)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("fndteh", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@tehcod", SqlDbType.Int).Value = tcod;
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                List<clstehprp> obj = new List<clstehprp>();
                if (dr.HasRows)
                {
                    dr.Read();
                    clstehprp k = new clstehprp();
                    k.tehcod = Convert.ToInt32(dr[0]);
                    k.tehnam = dr[1].ToString();
                    k.tehcltcod = Convert.ToInt32(dr[2]);
                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();
                return obj;
            }
        }
        public class clsmodfet : clscon
        {
            public void save_rec(clsmodfetprp p)
            {
                if (con.State == ConnectionState.Closed)
                {

                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("insmodfet", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@modfetmodcod", SqlDbType.Int).Value = p.modfetmodcod;
                cmd.Parameters.Add("@modfetfetcod", SqlDbType.Int).Value = p.modfetfetcod;
                cmd.Dispose();
                con.Close();
            }
            public void update_rec(clsmodfetprp p)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("updmodfet", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@modfetmodcod", SqlDbType.Int).Value = p.modfetmodcod;
                cmd.Parameters.Add("@modfetfetcod", SqlDbType.Int).Value = p.modfetfetcod;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public void delete_rec(clsmodfetprp p)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("delmodfet", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@modfetmodcod", SqlDbType.Int).Value = p.modfetmodcod;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public List<clsmodfetprp> display_rec()
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("dspmodfet", con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                List<clsmodfetprp> obj = new List<clsmodfetprp>();
                while (dr.Read())
                {
                    clsmodfetprp k = new clsmodfetprp();
                    k.modfetmodcod = Convert.ToInt32(dr[0]);
                    k.modfetfetcod = Convert.ToInt32(dr[1]);
                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();
                return obj;
            }
            public List<clsmodfetprp> find_rec(Int32 mfmodcod)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("fndmodfet", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@modfetmodcod", SqlDbType.Int).Value = mfmodcod;
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                List<clsmodfetprp> obj = new List<clsmodfetprp>();
                if (dr.HasRows)
                {
                    dr.Read();
                    clsmodfetprp k = new clsmodfetprp();
                    k.modfetmodcod = Convert.ToInt32(dr[0]);
                    k.modfetfetcod = Convert.ToInt32(dr[1]);
                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();
                return obj;
            }
        }
        public class clsmodacc : clscon
        {
            public void save_rec(clsmodaccprp p)
            {
                if (con.State == ConnectionState.Closed)
                {

                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("insmodacc", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@modaccmodcod", SqlDbType.Int).Value = p.modaccmodcod;
                cmd.Parameters.Add("@modaccacccod", SqlDbType.Int).Value = p.modaccacccod;
                cmd.Dispose();
                con.Close();
            }
            public void update_rec(clsmodaccprp p)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("updmodacc", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@modaccmodcod", SqlDbType.Int).Value = p.modaccmodcod;
                cmd.Parameters.Add("@modaccacccod", SqlDbType.Int).Value = p.modaccacccod;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public void delete_rec(clsmodaccprp p)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("delmodacc", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@modaccmodcod", SqlDbType.Int).Value = p.modaccmodcod;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public List<clsmodaccprp> display_rec()
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("dspmodacc", con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                List<clsmodaccprp> obj = new List<clsmodaccprp>();
                while (dr.Read())
                {
                    clsmodaccprp k = new clsmodaccprp();
                    k.modaccmodcod = Convert.ToInt32(dr[0]);
                    k.modaccacccod = Convert.ToInt32(dr[1]);
                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();
                return obj;
            }
            public List<clsmodaccprp> find_rec(Int32 mamodcod)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("fndmodacc", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@modaccmodcod", SqlDbType.Int).Value = mamodcod;
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                List<clsmodaccprp> obj = new List<clsmodaccprp>();
                if (dr.HasRows)
                {
                    dr.Read();
                    clsmodaccprp k = new clsmodaccprp();
                    k.modaccmodcod = Convert.ToInt32(dr[0]);
                    k.modaccacccod = Convert.ToInt32(dr[1]);
                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();
                return obj;
            }
        }
        public class clsreg : clscon
        {
            public Int32 getauto()
            {
                if (con.State == ConnectionState.Closed)
                {

                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("select isnull(max(regcod),2000) from tbreg");
                cmd.Connection = con;
                Int32 i = Convert.ToInt32(cmd.ExecuteScalar()) + 1;
                return i;
            }
            public void save_rec(clsregprp p)
            {
                if (con.State == ConnectionState.Closed)
                {

                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("insreg", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@regcod", SqlDbType.Int).Value = p.regcod;
                cmd.Parameters.Add("@regnam", SqlDbType.VarChar, 50).Value = p.regnam;
                cmd.Parameters.Add("@regadd", SqlDbType.VarChar, 200).Value = p.regadd;
                cmd.Parameters.Add("@regctycod", SqlDbType.Int).Value = p.regctycod;
                cmd.Parameters.Add("@regphn", SqlDbType.VarChar, 50).Value = p.regphn;
                cmd.Parameters.Add("@regeml", SqlDbType.VarChar, 50).Value = p.regeml;
                cmd.Parameters.Add("@regpin", SqlDbType.VarChar, 50).Value = p.regpin;
                cmd.Parameters.Add("@regmob", SqlDbType.VarChar, 50).Value = p.regmob;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public void update_rec(clsregprp p)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("updreg", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@regcod", SqlDbType.Int).Value = p.regcod;
                cmd.Parameters.Add("@regnam", SqlDbType.VarChar, 50).Value = p.regnam;
                cmd.Parameters.Add("@regadd", SqlDbType.VarChar, 200).Value = p.regadd;
                cmd.Parameters.Add("@regctycod", SqlDbType.Int).Value = p.regctycod;
                cmd.Parameters.Add("@regphn", SqlDbType.VarChar, 50).Value = p.regphn;
                cmd.Parameters.Add("@regeml", SqlDbType.VarChar, 50).Value = p.regeml;
                cmd.Parameters.Add("@regpin", SqlDbType.VarChar, 50).Value = p.regpin;
                cmd.Parameters.Add("@regmob", SqlDbType.VarChar, 50).Value = p.regmob;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public void delete_rec(clsregprp p)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("delreg", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@regcod", SqlDbType.Int).Value = p.regcod;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public List<clsregprp> display_rec()
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("dspreg", con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                List<clsregprp> obj = new List<clsregprp>();
                while (dr.Read())
                {
                    clsregprp k = new clsregprp();
                    k.regcod = Convert.ToInt32(dr[0]);
                    k.regnam = dr[1].ToString();
                    k.regadd = dr[2].ToString();
                    k.regctycod = Convert.ToInt32(dr[3]);
                    k.regphn = dr[4].ToString();
                    k.regeml = dr[5].ToString();
                    k.regpin = dr[6].ToString();
                    k.regmob = dr[7].ToString();
                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();
                return obj;
            }
            public List<clsregprp> find_rec(Int32 rcod)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("fndreg", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@regcod", SqlDbType.Int).Value = rcod;
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                List<clsregprp> obj = new List<clsregprp>();
                if (dr.HasRows)
                {
                    dr.Read();
                    clsregprp k = new clsregprp();
                    k.regcod = Convert.ToInt32(dr[0]);
                    k.regnam = dr[1].ToString();
                    k.regadd = dr[2].ToString();
                    k.regctycod = Convert.ToInt32(dr[3]);
                    k.regphn = dr[4].ToString();
                    k.regeml = dr[5].ToString();
                    k.regpin = dr[6].ToString();
                    k.regmob = dr[7].ToString();
                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();
                return obj;
            }
        }
        public class clsord : clscon
        {
            public Int32 getauto()
            {
                if (con.State == ConnectionState.Closed)
                {

                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("select isnull(max(ordcod),0) from tbord");
                cmd.Connection = con;
                Int32 i = Convert.ToInt32(cmd.ExecuteScalar()) + 1;
                return i;
            }
            public void save_rec(clsordprp p)
            {
                if (con.State == ConnectionState.Closed)
                {

                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("insord", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@ordcod", SqlDbType.Int).Value = p.ordcod;
                cmd.Parameters.Add("@orddat", SqlDbType.DateTime).Value = p.orddat;
                cmd.Parameters.Add("@ordregcod", SqlDbType.Int).Value = p.ordregcod;
                cmd.Parameters.Add("@orddelnam", SqlDbType.VarChar, 50).Value = p.orddelnam;
                cmd.Parameters.Add("@orddeladd", SqlDbType.VarChar, 200).Value = p.orddeladd;
                cmd.Parameters.Add("@orddelphn", SqlDbType.VarChar, 50).Value = p.orddelphn;
                cmd.Parameters.Add("@orddelmob", SqlDbType.VarChar, 50).Value = p.orddelmob;
                cmd.Parameters.Add("@ordctycod", SqlDbType.Int).Value = p.ordctycod;
                cmd.Parameters.Add("@ordsts", SqlDbType.Char, 1).Value = p.ordsts;
                cmd.Parameters.Add("@ordamt", SqlDbType.Int).Value = p.ordamt;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public void update_rec(clsordprp p)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("updord", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@ordcod", SqlDbType.Int).Value = p.ordcod;
                cmd.Parameters.Add("@orddat", SqlDbType.DateTime).Value = p.orddat;
                cmd.Parameters.Add("@ordregcod", SqlDbType.Int).Value = p.ordregcod;
                cmd.Parameters.Add("@orddelnam", SqlDbType.VarChar, 50).Value = p.orddelnam;
                cmd.Parameters.Add("@orddeladd", SqlDbType.VarChar, 200).Value = p.orddeladd;
                cmd.Parameters.Add("@orddelphn", SqlDbType.VarChar, 50).Value = p.orddelphn;
                cmd.Parameters.Add("@orddelmob", SqlDbType.VarChar, 50).Value = p.orddelmob;
                cmd.Parameters.Add("@ordctycod", SqlDbType.Int).Value = p.ordctycod;
                    cmd.Parameters.Add("@ordamt", SqlDbType.Int).Value = p.ordamt;
                cmd.Dispose();
                con.Close();
            }
            public void delete_rec(clsordprp p)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("delord", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@ordcod", SqlDbType.Int).Value = p.ordcod;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public List<clsordprp> display_rec()
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("dspord", con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                List<clsordprp> obj = new List<clsordprp>();
                while (dr.Read())
                {
                    clsordprp k = new clsordprp();
                    k.ordcod = Convert.ToInt32(dr[0]);
                    k.orddat = Convert.ToDateTime(dr[1]);
                    k.ordregcod = Convert.ToInt32(dr[2]);
                    k.orddelnam = dr[3].ToString();
                    k.orddelphn = dr[4].ToString();
                    k.orddelmob = dr[5].ToString();
                    k.ordctycod = Convert.ToInt32(dr[6]);
                    k.ordsts = Convert.ToChar (dr[7]);
                    k.orddeladd = dr[8].ToString();
                    k.ordamt = Convert.ToInt32(dr[9]);
                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();
                return obj;
            }
            public List<clsordprp> find_rec(Int32 ocod)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("ordreg", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@ordcod", SqlDbType.Int).Value = ocod;
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                List<clsordprp> obj = new List<clsordprp>();
                if (dr.HasRows)
                {
                    dr.Read();
                    clsordprp k = new clsordprp();
                    k.ordcod = Convert.ToInt32(dr[0]);
                    k.orddat = Convert.ToDateTime(dr[1]);
                    k.ordregcod = Convert.ToInt32(dr[2]);
                    k.orddelnam = dr[3].ToString();
                    k.orddelphn = dr[4].ToString();
                    k.orddelmob = dr[5].ToString();
                    k.ordctycod = Convert.ToInt32(dr[6]);
                    k.ordsts = Convert.ToChar(dr[7]);
                    k.orddeladd = dr[8].ToString();
                    k.ordamt = Convert.ToInt32(dr[9]);
                    obj.Add(k);
                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();
                return obj;
            }
        }
        public class clsorddet : clscon
        {
            public void save_rec(clsorddetprp p)
            {
                if (con.State == ConnectionState.Closed)
                {

                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("insorddet", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@orddetordcod", SqlDbType.Int).Value = p.orddetordcod;
                cmd.Parameters.Add("@orddetbokmodcod", SqlDbType.VarChar, 50).Value = p.orddetbokmodcod;
                cmd.Parameters.Add("@orddetqty", SqlDbType.Int).Value = p.orddetqty;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public void update_rec(clsorddetprp p)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("updorddet", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@orddetordcod", SqlDbType.Int).Value = p.orddetordcod;
                cmd.Parameters.Add("@orddetbokmodcod", SqlDbType.VarChar, 50).Value = p.orddetbokmodcod;
                cmd.Parameters.Add("@orddetqty", SqlDbType.Int).Value = p.orddetqty;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public void delete_rec(clsorddetprp p)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("delorddet", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@orddetordcod", SqlDbType.Int).Value = p.orddetordcod;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public List<clsorddetprp> display_rec()
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("dsporddet", con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                List<clsorddetprp> obj = new List<clsorddetprp>();
                while (dr.Read())
                {
                    clsorddetprp k = new clsorddetprp();
                    k.orddetordcod = Convert.ToInt32(dr[0]);
                    k.orddetbokmodcod = Convert.ToInt32(dr[1]);
                    k.orddetqty = Convert.ToInt32(dr[2]);
                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();
                return obj;
            }
            public List<clsorddetprp> find_rec(Int32 odordcod)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("fndorddet", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@orddetordcod", SqlDbType.Int).Value = odordcod;
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                List<clsorddetprp> obj = new List<clsorddetprp>();
                if (dr.HasRows)
                {
                    dr.Read();
                    clsorddetprp k = new clsorddetprp();
                    k.orddetordcod = Convert.ToInt32(dr[0]);
                    k.orddetbokmodcod = Convert.ToInt32(dr[1]);
                    k.orddetqty = Convert.ToInt32(dr[2]);
                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();
                return obj;
            }
        }
        public class clsnewrel : clscon
        {
            public void save_rec(clsnewrelprp p)
            {
                if (con.State == ConnectionState.Closed)
                {

                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("insnewrel", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@newrelbokmodcod", SqlDbType.Int).Value = p.newrelbokmodcod;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public void update_rec(clsnewrelprp p)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("updnewrel", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@newrelbokmodcod", SqlDbType.Int).Value = p.newrelbokmodcod;

                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public void delete_rec(clsnewrelprp p)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("delnewrel", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@newrelbokmodcod", SqlDbType.Int).Value = p.newrelbokmodcod;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public List<clsnewrelprp> display_rec()
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("dspnewrel", con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                List<clsnewrelprp> obj = new List<clsnewrelprp>();
                while (dr.Read())
                {
                    clsnewrelprp k = new clsnewrelprp();
                    k.newrelbokmodcod = Convert.ToInt32(dr[0]);
                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();
                return obj;
            }
            public List<clsnewrelprp> find_rec(Int32 nrbokmodcod)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("fndbokaut", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@newrelbokmodcod", SqlDbType.Int).Value = nrbokmodcod;
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                List<clsnewrelprp> obj = new List<clsnewrelprp>();
                if (dr.HasRows)
                {
                    dr.Read();
                    clsnewrelprp k = new clsnewrelprp();
                    k.newrelbokmodcod = Convert.ToInt32(dr[0]);
                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();
                return obj;
            }
        }
        public class 
            clsdis : clscon
        {
            public void save_rec(clsdisprp p)
            {
                if (con.State == ConnectionState.Closed)
                {

                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("insdis", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@disbokmodcod", SqlDbType.Int).Value = p.disbokmodcod;
                cmd.Parameters.Add("@disamt", SqlDbType.Int).Value = p.disamt;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public void update_rec(clsdisprp p)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("updis", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@disbokmodcod", SqlDbType.Int).Value = p.disbokmodcod;
                cmd.Parameters.Add("@disamt", SqlDbType.Int).Value = p.disamt;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public void delete_rec(clsdisprp p)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("deldis", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@disbokmodcod", SqlDbType.Int).Value = p.disbokmodcod;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public List<clsdisprp> display_rec()
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("dspdis", con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                List<clsdisprp> obj = new List<clsdisprp>();
                while (dr.Read())
                {
                    clsdisprp k = new clsdisprp();
                    k.disbokmodcod = Convert.ToInt32(dr[0]);
                    k.disamt = Convert.ToInt32(dr[1]);
                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();
                return obj;
            }
            public List<clsdisprp> find_rec(Int32 dbokmodcod)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("fnddis", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@disbokmodcod", SqlDbType.Int).Value = dbokmodcod;
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                List<clsdisprp> obj = new List<clsdisprp>();
                if (dr.HasRows)
                {
                    dr.Read();
                    clsdisprp k = new clsdisprp();
                    k.disbokmodcod = Convert.ToInt32(dr[0]);
                    k.disamt = Convert.ToInt32(dr[1]);
                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();
                return obj;
            }
        }
        public class clsavl : clscon
        {
            public void save_rec(clsavlprp p)
            {
                if (con.State == ConnectionState.Closed)
                {

                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("insavl", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@avlbokmodcod", SqlDbType.Int).Value = p.avlbokmodcod;
                cmd.Parameters.Add("@avldsc", SqlDbType.VarChar, 200).Value = p.avldsc;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public void update_rec(clsavlprp p)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("updavl", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@avlbokmodcod", SqlDbType.Int).Value = p.avlbokmodcod;
                cmd.Parameters.Add("@avldsc", SqlDbType.Int).Value = p.avldsc;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public void delete_rec(clsavlprp p)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("delavl", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@avlbokmodcod", SqlDbType.Int).Value = p.avlbokmodcod;
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            public List<clsavlprp> display_rec()
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("dspavl", con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                List<clsavlprp> obj = new List<clsavlprp>();
                while (dr.Read())
                {
                    clsavlprp k = new clsavlprp();
                    k.avlbokmodcod = Convert.ToInt32(dr[0]);
                    k.avldsc = dr[1].ToString();
                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();
                return obj;
            }
            public List<clsavlprp> find_rec(Int32 abokmodcod)
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("fndavl", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@avlbokmodcod", SqlDbType.Int).Value = abokmodcod;
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                List<clsavlprp> obj = new List<clsavlprp>();
                if (dr.HasRows)
                {
                    dr.Read();
                    clsavlprp k = new clsavlprp();
                    k.avlbokmodcod = Convert.ToInt32(dr[0]);
                    k.avldsc = dr[1].ToString(); ;
                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();
                return obj;
            }
        }
    public class clssch : clscon
    {
        public List<clsschprp> schbyisbn(String isb)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("schbyisbn", con);

            cmd.Parameters.Add("@bokisb", SqlDbType.VarChar, 50).Value = isb;
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clsschprp> obj = new List<clsschprp>();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    clsschprp k = new clsschprp();
                    k.bokcod = Convert.ToInt32(dr["bokcod"]);
                    k.bokisb = dr[0].ToString();
                    k.bokprc = Convert.ToInt32(dr[1]);
                    k.titnam = dr[2].ToString();
                    k.bokpic = dr["bokpic"].ToString();
                    k.pubnam = dr[4].ToString();
                      
                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();

            }
            return obj;
        }
        public List<clsschprp> schbyaut(String autnam)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("schbyaut", con);

            cmd.Parameters.Add("@autnam", SqlDbType.VarChar, 50).Value = autnam;
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clsschprp> obj = new List<clsschprp>();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    clsschprp k = new clsschprp();
                    k.bokcod = Convert.ToInt32(dr["bokcod"]);
                    k.bokisb = dr[0].ToString();
                    k.bokprc = Convert.ToInt32(dr[1]);
                    k.titnam = dr[2].ToString();
                    k.bokpic = dr["bokpic"].ToString();
                    k.pubnam = dr[4].ToString();
                   

                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();

            }
            return obj;
        }
        public List<clsschprp> schbytit(String titnam)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("schbytit", con);

            cmd.Parameters.Add("@titnam", SqlDbType.VarChar, 50).Value = titnam;
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clsschprp> obj = new List<clsschprp>();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    clsschprp k = new clsschprp();
                    k.bokcod = Convert.ToInt32(dr["bokcod"]);
                    k.bokisb = dr[0].ToString();
                    k.bokprc = Convert.ToInt32(dr[1]);
                    k.titnam = dr[2].ToString();
                    k.bokpic  = dr["bokpic"].ToString();
                    k.pubnam = dr[4].ToString();
                 
                 
                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();

            }
            return obj;
        }
        public List<clsschprp> schbypub(String pubnam)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("schbypub", con);

            cmd.Parameters.Add("@pubnam", SqlDbType.VarChar, 50).Value = pubnam;
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clsschprp> obj = new List<clsschprp>();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    clsschprp k = new clsschprp();
                    k.bokcod = Convert.ToInt32(dr["bokcod"]);
                    k.bokisb = dr[0].ToString();
                    k.bokprc = Convert.ToInt32(dr[1]);
                    k.titnam = dr[2].ToString();
                    k.bokpic = dr["bokpic"].ToString();
                    k.pubnam = dr[4].ToString();
                   

                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();

            }
            return obj;
        }
        public List<clsschprp> schbycat(String catnam)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("schbycat", con);

            cmd.Parameters.Add("@catnam", SqlDbType.VarChar, 50).Value = catnam;
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clsschprp> obj = new List<clsschprp>();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    clsschprp k = new clsschprp();
                    k.bokcod = Convert.ToInt32(dr["bokcod"]);
                    k.bokisb = dr[0].ToString();
                    k.bokprc = Convert.ToInt32(dr[1]);
                    k.titnam = dr[2].ToString();
                    k.bokpic = dr["bokpic"].ToString();
                    k.pubnam = dr[4].ToString();
                    
                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();

            }
            return obj;
        }
        public List<clsschprp> schbysub(String subnam)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = new SqlCommand("schbysub", con);

            cmd.Parameters.Add("@subnam", SqlDbType.VarChar, 50).Value = subnam;
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            List<clsschprp> obj = new List<clsschprp>();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    clsschprp k = new clsschprp();
                    k.bokcod = Convert.ToInt32(dr["bokcod"]);
                    k.bokisb = dr[0].ToString();
                    k.bokprc = Convert.ToInt32(dr[1]);
                    k.titnam = dr[2].ToString();
                    k.bokpic = dr["bokpic"].ToString();
                    k.pubnam = dr[4].ToString();
                  
                    obj.Add(k);
                }
                dr.Close();
                cmd.Dispose();
                con.Close();

            }
            return obj;
        }
    }
    public class clsschprp : intbok, inttit, intaut, intbokaut, intpub, intdis, intavl
    {


        #region intbok Members
        Int32 bc, btc, bpc, bprc, bnop, bcc;
        String bisb, bpic, bcmt;
        public int bokcod
        {
            get
            {
                return bc;
            }
            set
            {
                bc = value;
            }
        }

        public string bokisb
        {
            get
            {
                return bisb;
            }
            set
            {
                bisb = value;
            }
        }

        public int boktitcod
        {
            get
            {
                return btc;
            }
            set
            {
                btc = value;
            }
        }

        public int bokpubcod
        {
            get
            {
                return bpc;
            }
            set
            {
                bpc = value;
            }
        }

        public int bokprc
        {
            get
            {
                return bprc;
            }
            set
            {
                bprc = value;
            }
        }

        public string bokpic
        {
            get
            {
                return bpic;
            }
            set
            {
                bpic = value;
            }
        }

        public string bokcmt
        {
            get
            {
                return bcmt;
            }
            set
            {
                bcmt = value;
            }
        }

        public int boknop
        {
            get
            {
                return bnop;
            }
            set
            {
                bnop = value;
            }
        }

        public int bokcltcod
        {
            get
            {
                return bcc;
            }
            set
            {
                bcc = value;
            }
        }

        #endregion

        #region inttit Members
        Int32 tc, tsc;
        String tn;
        public int titcod
        {
            get
            {
                return tc;
            }
            set
            {
                tc = value;
            }
        }

        public string titnam
        {
            get
            {
                return tn;
            }
            set
            {
                tn = value;
            }
        }

        public int titsubcod
        {
            get
            {
                return tsc;
            }
            set
            {
                tsc = value;
            }
        }

        #endregion

        #region intaut Members
        Int32 ac;
        String an;
        public int autcod
        {
            get
            {
                return ac;
            }
            set
            {
                ac = value;
            }
        }

        public string autnam
        {
            get
            {
                return an;
            }
            set
            {
                an = value;
            }
        }

        #endregion

        #region intbokaut Members
        Int32 babc, baac;
        public int bokautbokcod
        {
            get
            {
                return babc;
            }
            set
            {
                babc = value;
            }
        }

        public int bokautautcod
        {
            get
            {
                return baac;
            }
            set
            {
                baac = value;
            }
        }

        #endregion

        #region intpub Members
        Int32 pc;
        String pn;
        public int pubcod
        {
            get
            {
                return pc;
            }
            set
            {
                pc = value;
            }
        }

        public string pubnam
        {
            get
            {
                return pn;
            }
            set
            {
                pn = value;
            }
        }

        #endregion

        #region intdis Members
        Int32 dbc, da;
        public int disbokmodcod
        {
            get
            {
                return dbc;
            }
            set
            {
                dbc = value;
            }
        }

        public int disamt
        {
            get
            {
                return da;
            }
            set
            {
                da = value;
            }
        }

        #endregion

        #region intavl Members
        Int32 abc;
        String ad;
        public int avlbokmodcod
        {
            get
            {
                return abc;
            }
            set
            {
                abc = value;
            }
        }

        public string avldsc
        {
            get
            {
                return ad;
            }
            set
            {
                ad = value;
            }
        }

        #endregion
    }
    }
