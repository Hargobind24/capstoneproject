using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class client_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        String st = "select ordcod,regnam,orddelnam,orddelphn,orddeladd,orddetbokmodcod,orddetqty,titnam,bokprc from tbord,tborddet,tbreg,tbbok,tbtit where ordcod=orddetordcod and ordsts='D' and ordregcod=regcod and orddetbokmodcod=bokcod and boktitcod=titcod and orddetbokmodcod in (select bokcod from tbbok where bokcltcod="+ Session["cltcod"].ToString() + ")";
       // Response.Write(st);
        SqlDataAdapter adp = new SqlDataAdapter(st, "database=gagan18;uid=sa;pwd=sumeet");
        DataSet ds = new DataSet();
        adp.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }
}
