using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
public partial class Default3 : System.Web.UI.Page
{
    nsb2b.clsbok obj = new nsb2b.clsbok();
    nsb2b.clsbokprp objprp = new nsb2b.clsbokprp();
    nsb2b.clsbokaut obj1 = new nsb2b.clsbokaut();
    nsb2b.clsbokautprp objprp1 = new nsb2b.clsbokautprp();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            drpcatnam.DataBind();
            drpsubnam.DataBind();
            drptitnam.DataBind();
            ListBox1.DataBind();
        }
    }
    protected void btncan_Click(object sender, EventArgs e)
    {
        txtisb.Text = "";
        txtnop.Text = "";
        txtcmt.Text = "";
        txtprc.Text = "";
       
    }
    protected void btnsav_Click(object sender, EventArgs e)
    {
        Int32 a=obj.getauto();
        objprp.bokcod =a;
        objprp.bokisb = txtisb.Text;
        objprp.boktitcod = Convert.ToInt32(drptitnam.SelectedValue);
        objprp.bokpubcod = Convert.ToInt32(drppubnam.SelectedValue);
        objprp.bokprc = Convert.ToInt32(txtprc.Text);
        String st = FileUpload1.PostedFile.FileName;
        Int32 i = st.LastIndexOf('\\');
        String fn = st.Substring(i + 1);
        objprp.bokpic  = fn;
        String  fp=Server.MapPath("~/images") + "/" + fn;
        FileUpload1.PostedFile.SaveAs(fp);
        objprp.bokcmt = txtcmt.Text;
        objprp.boknop = Convert.ToInt32(txtnop.Text);
        objprp.bokcltcod=Convert.ToInt32(Session["cltcod"]);
        obj.save_rec(objprp);
        for (Int32 j = 0; j < lstaut2.Items.Count; j++)
        {
            objprp1.bokautbokcod = a;
            objprp1.bokautautcod = Convert.ToInt32(lstaut2.Items[j].Value);
            obj1.save_rec(objprp1);
        }
        txtisb.Text = "";
        txtnop.Text = "";
        txtcmt.Text = "";
        txtprc.Text = "";

        ListBox1.DataBind();
    }
    protected void btnupd_Click(object sender, EventArgs e)
    {
        Int32 a = Convert.ToInt32(ListBox1.SelectedValue);
        objprp.bokcod = a;
        objprp.bokisb = txtisb.Text;
        objprp.boktitcod = Convert.ToInt32(drptitnam.SelectedValue);
        objprp.bokpubcod = Convert.ToInt32(drppubnam.SelectedValue);
        objprp.bokprc = Convert.ToInt32(txtprc.Text);
        String st = FileUpload1.PostedFile.FileName;
        Int32 i = st.LastIndexOf('\\');
        String fn = st.Substring(i + 1);
        objprp.bokpic = fn;
        String fp = Server.MapPath("../images") + "\\" + fn;
        FileUpload1.PostedFile.SaveAs(fp);
        objprp.bokcmt = txtcmt.Text;
        objprp.boknop = Convert.ToInt32(txtnop.Text);
        objprp.bokcltcod = Convert.ToInt32(Session["cltcod"]);
        obj.update_rec(objprp);
        objprp1.bokautbokcod=a;
        obj1.delete_rec(objprp1);
        for (Int32 j = 0; j < lstaut2.Items.Count; j++)
        {
            objprp1.bokautbokcod = a;
            objprp1.bokautautcod = Convert.ToInt32(lstaut2.Items[j].Value);
            obj1.save_rec(objprp1);
        }
        txtisb.Text = "";
        txtnop.Text = "";
        txtcmt.Text = "";
        txtprc.Text = "";
        
    }
    protected void btndel_Click(object sender, EventArgs e)
    {
        Int32 a = Convert.ToInt32(ListBox1.SelectedValue);
        objprp.bokcod = a;
        obj.delete_rec(objprp);
        objprp1.bokautbokcod = a;
        obj1.delete_rec(objprp1);
        ListBox1.DataBind();
    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        lstaut2.Items.Add(new ListItem(lstaut1.SelectedItem.Text, lstaut1.SelectedValue));
    }
    protected void btnrem_Click(object sender, EventArgs e)
    {
        lstaut2.Items.Remove(new ListItem(lstaut2.SelectedItem.Text, lstaut2.SelectedValue));
    }

    protected void drpcatnam_SelectedIndexChanged(object sender, EventArgs e)
    {
        drpsubnam.DataBind();
        drptitnam.DataBind();
    }
    protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
        lstaut2.Items.Clear();
        List<nsb2b.clsautprp> aa=new List<nsb2b.clsautprp>();
        List<nsb2b.clsbokprp> k = obj.find_rec(Convert.ToInt32(ListBox1.SelectedValue), out   aa);
        if (k.Count > 0)
        {
            txtisb.Text  = k[0].bokisb;
            txtnop.Text = k[0].boknop.ToString();
            txtcmt.Text = k[0].bokcmt;
            txtprc.Text = k[0].bokprc.ToString();
            Image1.ImageUrl = Server.MapPath("../images") + "\\" + k[0].bokpic.ToString();
            drppubnam.SelectedIndex = -1;
            drppubnam.Items.FindByValue(k[0].bokpubcod.ToString()).Selected = true;
            for(int i=0;i<aa.Count ;i++)
            {
                lstaut2.Items.Add(new ListItem(aa[i].autnam.ToString(), aa[i].autcod.ToString()));
            }
        }
    }
}
