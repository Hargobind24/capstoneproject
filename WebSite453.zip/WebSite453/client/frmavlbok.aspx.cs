using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class _Default : System.Web.UI.Page
{
    nsb2b.clsclt obj = new nsb2b.clsclt();
    nsb2b.clscltprp objprp = new nsb2b.clscltprp();
    nsb2b.clsavl obj1 = new nsb2b.clsavl();
    nsb2b.clsavlprp obj1prp = new nsb2b.clsavlprp();
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }
    protected void drpcatnam_SelectedIndexChanged(object sender, EventArgs e)
    {
        drpsubnam.DataBind();
        drptitnam.DataBind();

    }
    protected void drptitnam_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }
    protected void btnsub_Click(object sender, EventArgs e)
    {
        if (Convert.ToInt32(ViewState["cc"]) == 0 && CheckBox1.Checked == true)
        {
            obj1prp.avlbokmodcod = Convert.ToInt32(ViewState["abc"]);
            obj1prp.avldsc = txtdsc.Text;
            obj1.save_rec(obj1prp);
        } else if (Convert.ToInt32(ViewState["cc"]) != 0 && CheckBox1.Checked == false)
        {
            obj1prp.avlbokmodcod = Convert.ToInt32(ViewState["abc"]);
            obj1.delete_rec(obj1prp);
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        SqlDataAdapter adp = new SqlDataAdapter("select bokisb,bokpic,boknop,bokprc,pubnam,bokcmt,bokcod from tbbok,tbpub where bokpubcod=pubcod and boktitcod=" + drptitnam.SelectedValue.ToString() + " and bokcltcod =" + Session["cltcod"].ToString(), ConfigurationManager.ConnectionStrings["cn"].ConnectionString);
        DataSet ds = new DataSet();
        adp.Fill(ds);
        DataList1.DataSource = ds;
        DataList1.DataBind();
        if (ds.Tables[0].Rows.Count > 0)
        {
            Int32 i = Convert.ToInt32(ds.Tables[0].Rows[0]["bokcod"].ToString());
            ViewState["abc"] = i;
            SqlDataAdapter adp1 = new SqlDataAdapter(" select avlbokmodcod,avldsc from tbavl where avlbokmodcod=" + i.ToString(), ConfigurationManager.ConnectionStrings["cn"].ConnectionString);
            DataSet ds1 = new DataSet();
            adp1.Fill(ds1);
            ViewState["cc"] = Convert.ToInt32(ds1.Tables[0].Rows.Count);
            if (ds1.Tables[0].Rows.Count > 0)
            {
                CheckBox1.Checked = true;
                
            }
            else
            {
                CheckBox1.Checked = false;
            }
        }


    }
}
