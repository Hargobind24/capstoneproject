using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class client_frmchgpwd : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
            SqlDataAdapter adp = new SqlDataAdapter("select usrpwd from tbusr where usrcltregcod=" + Session["cltcod"].ToString(), ConfigurationManager.ConnectionStrings["cn"].ConnectionString);
            DataSet ds = new DataSet();
            adp.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                if (ds.Tables[0].Rows[0][0].ToString() == TextBox1.Text)
                {
                    SqlConnection con = new SqlConnection();
                    con.ConnectionString = ConfigurationManager.ConnectionStrings["cn"].ConnectionString;
                    con.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = "update tbusr set usrpwd='" + TextBox2.Text + "' where usrcltregcod=" + Session["cltcod"].ToString();
                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();
                    Response.Write("Password Updated");
                }
                else
                {
                    Response.Write("Old Password is wrong");
                }
            
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox2.Text = "";
        TextBox2.Focus();
    }
}
