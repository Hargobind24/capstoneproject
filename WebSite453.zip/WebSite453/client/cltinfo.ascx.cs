using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class cltinfo : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Int32 i = Convert.ToInt32(Session["cltcod"]);
        SqlDataAdapter adp = new SqlDataAdapter("select * from tbclt where cltcod=" + i.ToString(), ConfigurationManager.ConnectionStrings["cn"].ConnectionString);
        DataSet ds = new DataSet();
        adp.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            Lbnam.Text = ds.Tables[0].Rows[0]["cltnam"].ToString();
            Lbadd.Text = ds.Tables[0].Rows[0]["cltadd"].ToString();
            Lbphn.Text = ds.Tables[0].Rows[0]["cltphn"].ToString();
             Lbfax.Text = ds.Tables[0].Rows[0]["cltfax"].ToString();
             Lbeml.Text = ds.Tables[0].Rows[0]["clteml"].ToString();
        //     Lbpic.Text = ds.Tables[0].Rows[0]["cltpic"].ToString();
        }
    }
}
