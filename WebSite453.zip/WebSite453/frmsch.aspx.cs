using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic ;
public partial class frmsch : System.Web.UI.Page
{
    nsb2b.clssch obj = new nsb2b.clssch();
    List<nsb2b.clsschprp> obj1 = new List<nsb2b.clsschprp>();
    protected void Page_Load(object sender, EventArgs e)
    {
        if(Page.IsPostBack ==false )
        {
        String schnam = (Request.QueryString["schnam"]).ToString();
        String schcat = Request.QueryString["schcat"].ToString();
        switch (schcat)
        {
            case "ISBN":
                {
                    obj1 = obj.schbyisbn('%' + schnam + '%');
                    break;
                }
            case "Title":
                {
                    obj1 = obj.schbytit("%" + schnam + "%");
                    break;
                }
            case "Author":
                {
                    obj1 = obj.schbyaut("%" + schnam + "%");
                    break;
                }
            case "Publisher":
                {
                    obj1 = obj.schbypub("%" + schnam + "%");
                    break;
                }
            case "Category":
                {
                    obj1 = obj.schbycat("%" + schnam + "%");
                    break;
                }
            case "Subject":
                {
                    obj1 = obj.schbysub("%" + schnam + "%");
                    break;
                }
            case "Keyword":
                {
                    Response.Write("keyword");
                    break;
                }
        }
        DataList1.DataSource = obj1;
        DataList1.DataBind();
        if (obj1.Count == 0)
        {
            Label1.Text = "No results matching this criteria";
        }
        else
            Label1.Text = "";
    }
    }
    protected void DataList1_EditCommand(object source, DataListCommandEventArgs e)
    {
        String s = DataList1.DataKeys[e.Item.ItemIndex].ToString();
        Response.Redirect("frmbokdet.aspx?bokid=" + s);
    }
    protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Response.Redirect("frmviewcart.aspx?bokid=" + DataList1.DataKeys[DataList1.SelectedIndex].ToString());
    }
}
