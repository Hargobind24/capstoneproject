using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class frmreg : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void txtconpwd_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        nsb2b.clsreg obj = new nsb2b.clsreg();
        nsb2b.clsregprp objprp = new nsb2b.clsregprp();
        Int32 a = obj.getauto();
        objprp.regcod = a;
        objprp.regnam = txtnam.Text;
        objprp.regadd = txtadd.Text;
        objprp.regctycod = Convert.ToInt32(DropDownList3.SelectedValue);
        objprp.regeml = txteml.Text;
        objprp.regmob = txtmob.Text;
        objprp.regphn = txtphn.Text;
        objprp.regpin = txtpin.Text;
        obj.save_rec(objprp);
        nsb2b.clsusr obj1 = new nsb2b.clsusr();
        nsb2b.clsusrprp objprp1 = new nsb2b.clsusrprp();
        objprp1.usrcltregcod = a;
        objprp1.usrnam = txtusr.Text;
        objprp1.usrpwd = txtpwd.Text;
        objprp1.usrsts = "U";
        obj1.save_rec(objprp1);
        Response.Redirect("frmchkusr.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        txtadd.Text = "";
        txtconpwd.Text = "";
        txteml.Text = "";
        txtmob.Text = "";
        txtnam.Text = "";
        txtphn.Text = "";
        txtpin.Text = "";
        txtpwd.Text = "";
        txtusr.Text="";
        txtnam.Focus();
    }
}
