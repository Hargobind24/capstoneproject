using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class frmmorbooks : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            if (Session["case"] == null && Session["case1"]==null)
            {
                SqlDataAdapter adp = new SqlDataAdapter("select count(*) from tbbok where  bokcod not in(select disbokmodcod from tbdis) and bokcod not in (select newrelbokmodcod  from tbnewrel) and bokcod not in(select avlbokmodcod from tbavl)", ConfigurationManager.ConnectionStrings["cn"].ConnectionString);
                DataSet ds = new DataSet();
                adp.Fill(ds);
                Int32 nor = Convert.ToInt32(ds.Tables[0].Rows[0][0]);
                Int32 c;
                if (nor % 4 == 0)
                {
                    c = nor / 4;
                }
                else
                {
                    c = nor / 4 + 1;
                }
                ArrayList a = new ArrayList();
                for (Int32 i = 1; i <= c; i++)
                {
                    a.Add(i.ToString());
                }
                DataList2.DataSource = a;
                DataList2.DataBind();
                bind(1);
            }
            else
            {
                if (Session["case"].ToString() == "")
                {
                    if (Session["case1"].ToString() != "")
                    {
                        SqlDataAdapter adp = new SqlDataAdapter("select BokCod,bokprc,TitNam,PubNam,BokPic from tbBok,tbTit,tbPub,tbCat,tbSub where BokTitCod=TitCod and BokPubCod=PubCod and SubCatCod=CatCod and TitSubCod=SubCod and BokCod in(select bokautBokCod from tbbokaut where " + Session["Case1"].ToString() + ")", "database=gagan18;uid=sa");
                        DataSet ds = new DataSet();
                        adp.Fill(ds);
                        DataList1.DataSource = ds;
                        DataList1.DataBind();
                    }
                    Session.Remove("case1");
                }
                else
                {
                    if(Session["case1"]==null)
                    {
                        SqlDataAdapter  adp=new  SqlDataAdapter("select BokCod,bokprc,TitNam,PubNam,BokPic from tbBok,tbTit,tbPub,tbCat,tbSub where BokTitCod=TitCod and BokPubCod=PubCod and SubCatCod=CatCod and TitSubCod=SubCod and " + Session["Case"].ToString(),"database=gagan18;uid=sa");
                         DataSet ds = new DataSet();
                        adp.Fill(ds);
                        DataList1.DataSource = ds;
                        DataList1.DataBind();
                    }
                    else
                    {
                        //String s = "select BokCod,TitNam,bokprc,PubNam,BokPic from tbBok,tbTit,tbPub,tbCat,tbSub where BokTitCod=TitCod and BokPubCod=PubCod and SubCatCod=CatCod and TitSubCod=SubCod and BokCod in(select AutDetBokCod from tbAutDet where " + Session["Case1"].ToString() + ")  and " + Session["Case"].ToString();
                        //Response.Write(s);
                        SqlDataAdapter adp = new SqlDataAdapter("select BokCod,TitNam,bokprc,PubNam,BokPic from tbBok,tbTit,tbPub,tbCat,tbSub where BokTitCod=TitCod and BokPubCod=PubCod and SubCatCod=CatCod and TitSubCod=SubCod and BokCod in(select bokdetBokCod from tbbokaut where " + Session["Case1"].ToString() + ")  and " + Session["Case"].ToString(), "database=gagan18;uid=sa");
                        DataSet ds = new DataSet();
                        adp.Fill(ds);
                        DataList1.DataSource = ds;
                        DataList1.DataBind();
                    }
                    Session.Remove("Case");
                    Session.Remove("Case1");
                }

            }
        }
    }
    private void bind(Int32 pgno)
    {
        SqlDataAdapter adp = new SqlDataAdapter("paging11", ConfigurationManager.ConnectionStrings["cn"].ConnectionString);
        adp.SelectCommand.CommandType = CommandType.StoredProcedure;
        adp.SelectCommand.Parameters.Add("@pageno", SqlDbType.Int).Value = pgno;
        DataSet ds = new DataSet();
        adp.Fill(ds);
        DataList1.DataSource = ds;
        DataList1.DataBind();

    }
    protected void DataList2_EditCommand(object source, DataListCommandEventArgs e)
    {
        bind(Convert.ToInt32(e.Item.ItemIndex) + 1);
    }
    protected void DataList1_EditCommand(object source, DataListCommandEventArgs e)
    {
        String s = DataList1.DataKeys[e.Item.ItemIndex].ToString();
        Response.Redirect("frmbokdet.aspx?bokid=" + s);
    }
    protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Response.Redirect("frmviewcart.aspx?bokid=" + DataList1.DataKeys[DataList1.SelectedIndex].ToString());
    }
}
