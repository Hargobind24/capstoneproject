using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class Default2 : System.Web.UI.Page
{
    nsb2b.clsusrprp objprp = new nsb2b.clsusrprp();
    nsb2b.clsusr obj = new nsb2b.clsusr();
  nsb2b.clsbok obj1 = new nsb2b.clsbok();
  nsb2b.clsbokprp obj1prp = new nsb2b.clsbokprp();
  nsb2b.clsnewrel obj2 = new nsb2b.clsnewrel();
  nsb2b.clsnewrelprp obj2prp = new nsb2b.clsnewrelprp();


    protected void Page_Load(object sender, EventArgs e)
    {
        
        this.SmartNavigation = true;
       
        if (Page.IsPostBack == false)
        {
            bind1();
            bind2();
          //  bind3();
        }
    }
    protected void btnlog_Click(object sender, EventArgs e)
    {
        

    }

    protected void lnkclt_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmclt.aspx");
    }

    private void bind1()
    {
        String st = "select  bokcod,titnam,bokprc,bokpic from tbbok,tbtit where boktitcod=titcod and bokcod in(select newrelbokmodcod from tbnewrel)";
        SqlDataAdapter adp = new SqlDataAdapter(st, ConfigurationManager.ConnectionStrings["cn"].ConnectionString);
        DataSet ds = new DataSet();
        adp.Fill(ds);
      DataList1.DataSource =ds;
        DataList1.DataBind();
    }
    private void bind2()
    {
        String st = "select top 5  bokcod,titnam,bokprc,bokpic,disamt from tbbok,tbtit,tbdis where boktitcod=titcod and bokcod=disbokmodcod and bokcod in(select disbokmodcod from tbdis)";
        SqlDataAdapter adp = new SqlDataAdapter(st, ConfigurationManager.ConnectionStrings["cn"].ConnectionString);
        DataSet ds = new DataSet();
        adp.Fill(ds);
        DataList2.DataSource = ds;
        DataList2.DataBind();
    }


    protected void DataList1_EditCommand(object source, DataListCommandEventArgs e)
    {
        String s = DataList1.DataKeys[e.Item.ItemIndex].ToString();
        Response.Redirect("frmbokdet.aspx?bokid=" + s);
    }
    protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Response.Redirect("frmviewcart.aspx?bokid=" + DataList1.DataKeys[DataList1.SelectedIndex].ToString());
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("frmmorbooks.aspx");
    }
    protected void DataList2_EditCommand(object source, DataListCommandEventArgs e)
    {
        String s = DataList2.DataKeys[e.Item.ItemIndex].ToString();
        Response.Redirect("frmbokdet.aspx?bokid=" + s);
    }
    protected void DataList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        Response.Redirect("frmviewcart.aspx?bokid=" + DataList2.DataKeys[DataList2.SelectedIndex].ToString());
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmmorbooks.aspx");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmsch.aspx?schnam=" + TextBox1.Text + "&schcat=" + DropDownList1.SelectedItem.Text);
    }
    protected void ImageButton1_Click1(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("frmsch.aspx?schnam=" + TextBox1.Text + "&schcat=" + DropDownList1.SelectedItem.Text);

    }
    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("frmmorbooks.aspx");
    }
    protected void LinkButton1_Click1(object sender, EventArgs e)
    {
        Response.Redirect("frmmordisbok.aspx");
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmadvsch.aspx");
    }
    protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
    {
        Int32 r = obj.checkuser(txthomusr.Text, txthompwd.Text);
        if (r == -1)
        {
            Label1.Visible = true;
            Label1.Text = "user does not exist";
        }
        else if (r == 1)
        {
            Label1.Visible = true;
            Label1.Text = "login confirmed";
            SqlDataAdapter adp = new SqlDataAdapter("select usrcltregcod,usrsts from tbusr where usrnam='" + txthomusr.Text + "' and usrpwd='" + txthompwd.Text + "'", ConfigurationManager.ConnectionStrings["cn"].ConnectionString);
            DataSet ds = new DataSet();
            adp.Fill(ds);
            Session["cltcod"] = ds.Tables[0].Rows[0][0].ToString();
            String st = "";
            if (ds.Tables[0].Rows[0][1].ToString() == "A")
                st = "A";
            else if (ds.Tables[0].Rows[0][1].ToString() == "C")
                st = "C";
            Session["stcode"] = st;
            FormsAuthenticationTicket tk = new FormsAuthenticationTicket(1, txthomusr.Text, DateTime.Now, DateTime.Now.AddHours(4), false, st);
            string s = FormsAuthentication.Encrypt(tk);
            HttpCookie ck = new HttpCookie(FormsAuthentication.FormsCookieName, s);
            Response.Cookies.Add(ck);
            Response.Redirect("default.aspx");
        }
        else if (r == -2)
        {
            Label1.Visible = true;
            Label1.Text = "wrong password";
        }
    }
}