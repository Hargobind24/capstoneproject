using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            CheckBox4.Enabled = false;
            CheckBox5.Enabled = false;
            DropDownList1.Enabled = false;
            DropDownList2.Enabled = false;
            DropDownList3.Enabled = false;
            DropDownList4.Enabled = false;
            DropDownList5.Enabled = false;
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        String st="";
       String  st1="";
        if(CheckBox1.Checked ==true)
        {
            st1 = "bokautAutCod=" + DropDownList1.SelectedValue.ToString();
            if(CheckBox2.Checked ==true)
            {
                st = "PubCod=" + DropDownList2.SelectedValue.ToString();
                if(CheckBox3.Checked ==true)
                {
                    st += " and CatCod=" + DropDownList3.SelectedValue.ToString();
                    if(CheckBox4.Checked ==true)
                    {
                        st += " and SubCod=" + DropDownList4.SelectedValue.ToString();
                        if(CheckBox5.Checked ==true )
                        {
                            st += " and TitCod=" + DropDownList5.SelectedValue.ToString();
                        }
                    }
               }
            }
                else
            {
                if(CheckBox3.Checked ==true)
                {
                    st += " and CatCod=" + DropDownList3.SelectedValue.ToString();
                   if(CheckBox4.Checked ==true )
                    {
                        st += " and SubCod=" + DropDownList4.SelectedValue.ToString();
                        if(CheckBox5.Checked ==true)
                    {
                            st += " and TitCod=" + DropDownList5.SelectedValue.ToString();
                }
                }
                }
            }
            Session["Case1"] = st1;
        }
        else
        {
           if(CheckBox2.Checked ==true)
           {
                st = "PubCod=" + DropDownList2.SelectedValue.ToString();
               if(CheckBox3.Checked ==true)
               {
                    st += " and CatCod=" + DropDownList3.SelectedValue.ToString();
                    if(CheckBox4.Checked ==true)
                   {
                        st += " and SubCod=" + DropDownList4.SelectedValue.ToString();
                        if(CheckBox5.Checked ==true)
                          {
                            st += " and TitCod=" + DropDownList5.SelectedValue.ToString();
                          }
                   }
               }
           }
           else
           {
                if(CheckBox3.Checked ==true)
               {
                    st = "CatCod=" + DropDownList3.SelectedValue.ToString();
                    if(CheckBox4.Checked ==true)
                    {
                        st += " and SubCod=" + DropDownList4.SelectedValue.ToString();
                        if(CheckBox5.Checked ==true)
                        {
                            st += " and TitCod=" + DropDownList5.SelectedValue.ToString();
                        }
                    }
               }
           }
        }
        Session["Case"] = st;
        Response.Redirect("frmmorbooks.aspx");
    }
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        DropDownList1.Enabled = true;
    }
    protected void CheckBox2_CheckedChanged(object sender, EventArgs e)
    {
        DropDownList2.Enabled = true;
    }
    protected void CheckBox3_CheckedChanged(object sender, EventArgs e)
    {
        DropDownList3.Enabled = true;
        CheckBox4.Enabled = true;
    }
    protected void CheckBox4_CheckedChanged(object sender, EventArgs e)
    {
        DropDownList4.Enabled = true;
        CheckBox5.Enabled = true;
    }
    protected void CheckBox5_CheckedChanged(object sender, EventArgs e)
    {
        DropDownList5.Enabled = true;
    }
}
