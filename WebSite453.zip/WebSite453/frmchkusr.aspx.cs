using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class frmchkusr : System.Web.UI.Page
{
    nsb2b.clsusr obj = new nsb2b.clsusr();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (User.Identity.IsAuthenticated == true)
        {
            Response.Redirect("frmdeldet.aspx");
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (RadioButton1.Checked == true)
        {
            Response.Redirect("frmreg.aspx");
        }
        else
        {
            Panel1.Visible = true;
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Int32 r = obj.checkuser(TextBox1.Text , TextBox2.Text);
        if (r == -1)
        {
           // Label1.Visible = true;
          // Label1.Text = "user does not exist";
        }
        else if (r == 1)
        {
          // Label1.Visible = true;
          // Label1.Text = "login confirmed";
            SqlDataAdapter adp = new SqlDataAdapter("select usrcltregcod,usrsts from tbusr where usrnam='" + TextBox1 .Text + "' and usrpwd='" +TextBox2 .Text + "'", ConfigurationManager.ConnectionStrings["cn"].ConnectionString);
            DataSet ds = new DataSet();
            adp.Fill(ds);
            Session["cltcod"] = ds.Tables[0].Rows[0][0].ToString();
            String st = "";
            if (ds.Tables[0].Rows[0][1].ToString() == "A")
                st = "A";
            else if (ds.Tables[0].Rows[0][1].ToString() == "C")
                st = "C";
            else if (ds.Tables[0].Rows[0][1].ToString() == "U")
                st = "U";
            FormsAuthenticationTicket tk = new FormsAuthenticationTicket(1, TextBox1.Text, DateTime.Now, DateTime.Now.AddHours(4), false, st);
            string s = FormsAuthentication.Encrypt(tk);
            HttpCookie ck = new HttpCookie(FormsAuthentication.FormsCookieName, s);
            Response.Cookies.Add(ck);
            Session["stk"] = "m";
            Response.Redirect("default.aspx");
         

        }
        else if (r == -2)
        {
          //Label1.Visible = true;
        // Label1.Text = "wrong password";
        }

    }
}
